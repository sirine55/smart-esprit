#include <gtk/gtk.h>
typedef struct
{
    int jour;
    int mois;
    int annee;
}date;

typedef struct
{
    int hh;
    int mm;
    int s;
}heure;

typedef struct
{
    char ref_cap[50];
    date date_prise;
    float val;
    heure heure_prise;
}datasheet;

typedef struct
{
    char bloc[10];
    int etage;
}position;

typedef struct
{
    char ref_cap[50];
    char type[30];
    date date_achat;
    char etat[10];
    datasheet sh;
    int val_max;
    int val_min;
    position pos;
    date entretient;  //nzidou tab3ath alerte!!!!!
}capteur;

typedef struct
{
int num;
int jour;
int heure;
int val;
}alarme;


typedef struct
{
int num;
int jour;
int heure;
float val;
}temperature;


void ajouter_capteur(capteur cap);
int verifier_capteur(char ref_cap[]);
capteur recherche(char ref_s[]);
void modifier_capteur(capteur cap_m);
void afficher_par_bloc(GtkWidget *liste,char bloc[]);
void afficher_on(GtkWidget *liste,char bloc[]);
void afficher_off(GtkWidget *liste,char bloc[]);
void afficher_panne(GtkWidget *liste,char bloc[]);
void vider(GtkWidget *liste);
void supprimer_capteur(char ref_cap[]);

/*//void activer_capteur(int ref_cap);  //zeyda
//void desactiver_capteur(int ref_cap);   //zeyda
void etat_capteur(char ref_cap[],int etat);
/*void afficher_capteur(int ref_capteur);
*/
void supprimer_alarme(alarme al,char type[]);
void afficher_alarme(GtkWidget *liste);
void afficher_fumee_alarme(GtkWidget *liste);
void afficher_mouv_alarme(GtkWidget *liste);
void vider_alarme(GtkWidget *liste);

void supprimer_temperature(temperature temp);
void afficher_temperature(GtkWidget *liste);
//void vider_temperature(GtkWidget *liste);

void treeview_popup_menu_modifier (GtkWidget *menuitem, gpointer userdata,GtkTreePath *path);
void treeview_popup_menu_supprimer (GtkWidget *menuitem, gpointer userdata,GtkTreePath *path);
void treeview_popup_menu (GtkWidget *treeview, GdkEventButton *event, gpointer userdata,GtkTreePath *path);
