#include <gtk/gtk.h>


void
on_button56_ajoutercapteur_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button66_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button57_annuler_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button69_afficher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button67_modifier_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button66_ajouter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button68_supprimer_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton2_off_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_on_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button66_chercher_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button66_chercher_ajouter_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button60_mod_cap_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_radiobutton5_panne_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_off_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_on_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button61_r_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button65_retour_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button64_conf_supp_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview12_blocA_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview13_blocB_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview14_blocC_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview15_blocD_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview16_blocE_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview17_blocG_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview18_blocI_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview19_blocJ_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview20_blocK_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_panne_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_off_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_on_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_actualiser_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajuster_aj_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview21_alarme_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_alarme_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_alac_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_fumee_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mouv_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retoura_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview22_def_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button67_defec_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button68_chercher_ref_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button69_cap_retour_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button70_retour_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_liste_capteur_actualiser_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
