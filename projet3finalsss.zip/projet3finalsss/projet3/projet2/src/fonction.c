
#include <gtk/gtk.h>
#include <stdio.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include <string.h>

enum
{
	Eref,
	Etype,
	Eetat,
	COLUMNS
};

void ajouter_capteur(capteur cap) //ok
 {
     FILE* f;
     f=fopen("fichier_capteur.txt","a");
     fprintf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,cap.date_achat.jour,cap.date_achat.mois,cap.date_achat.annee,cap.etat,cap.sh.date_prise.jour,cap.sh.date_prise.mois,cap.sh.date_prise.annee,cap.sh.heure_prise.s,cap.sh.heure_prise.mm,cap.sh.heure_prise.hh,cap.sh.val,cap.val_min,cap.val_max,cap.pos.bloc,cap.pos.etage,cap.entretient.jour,cap.entretient.mois,cap.entretient.annee);
     fclose(f);
 }
int verifier_capteur(char ref_s[])   //ok
{
    FILE* f;
    capteur cap;
    f=fopen("fichier_capteur.txt","r");
    if(f!=NULL)
    {
       while(!feof(f))
       {
           fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,cap.etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee);
           if(strcmp(ref_s,cap.ref_cap)==0)//existe
           {
               fclose(f);
               return 1;
           }
       }
       fclose(f);//n'existe pas
       return 0;
    }
}

capteur recherche(char ref_s[])   //ok
{
    FILE* f;
    capteur cap;
    f=fopen("fichier_capteur.txt","r");
    if(f!=NULL)
    {
       while(!feof(f))
       {
           fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,cap.etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee);
           if(strcmp(ref_s,cap.ref_cap)==0)//existe
           {
               fclose(f);
               return cap;
           }
       }
    }
}

void modifier_capteur(capteur cap_m)//ok
{
FILE* f;FILE* f0;
capteur cap;
int choix;
f0=fopen("tmp.txt","w");
f=fopen("fichier_capteur.txt","r");

if(f!=NULL)
{
	while(!feof(f))
        {
        	fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n"
,cap.ref_cap,cap.type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,cap.etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee);
         	if(strcmp(cap_m.ref_cap,cap.ref_cap)!=0)
           	{
                	fprintf(f0,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n"
,cap.ref_cap,cap.type,cap.date_achat.jour,cap.date_achat.mois,cap.date_achat.annee,cap.etat,cap.sh.date_prise.jour,cap.sh.date_prise.mois,cap.sh.date_prise.annee,cap.sh.heure_prise.s,cap.sh.heure_prise.mm,cap.sh.heure_prise.hh,cap.sh.val,cap.val_min,cap.val_max,cap.pos.bloc,cap.pos.etage,cap.entretient.jour,cap.entretient.mois,cap.entretient.annee);
            	}
            	else
            	{
               
                fprintf(f0,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
cap_m.ref_cap,cap_m.type,cap_m.date_achat.jour,cap_m.date_achat.mois,cap_m.date_achat.annee,cap_m.etat,cap_m.sh.date_prise.jour,cap_m.sh.date_prise.mois,cap_m.sh.date_prise.annee,cap_m.sh.heure_prise.s,cap_m.sh.heure_prise.mm,cap_m.sh.heure_prise.hh,cap_m.sh.val,cap_m.val_min,cap_m.val_max,cap_m.pos.bloc,cap_m.pos.etage,cap_m.entretient.jour,cap_m.entretient.mois,cap_m.entretient.annee);

            }
        }
        fclose(f);
        fclose(f0);
        remove("fichier_capteur.txt");
        rename("tmp.txt","fichier_capteur.txt");
    }
}

void supprimer_capteur(char ref_s[]) //ok
{
    FILE* f;FILE* f0;
    int choix;
    capteur cap;
    f0=fopen("tmp.txt","w");
    f=fopen("fichier_capteur.txt","r");
    if(f!=NULL)
    {
        while(!feof(f))
        {
            fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,cap.etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee);
            if(strcmp(ref_s,cap.ref_cap)!=0)
                fprintf(f0,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,cap.date_achat.jour,cap.date_achat.mois,cap.date_achat.annee,cap.etat,cap.sh.date_prise.jour,cap.sh.date_prise.mois,cap.sh.date_prise.annee,cap.sh.heure_prise.s,cap.sh.heure_prise.mm,cap.sh.heure_prise.hh,cap.sh.val,cap.val_min,cap.val_max,cap.pos.bloc,cap.pos.etage,cap.entretient.jour,cap.entretient.mois,cap.entretient.annee);
        }
        fclose(f);
        fclose(f0);
        remove("fichier_capteur.txt");
        rename("tmp.txt","fichier_capteur.txt");
    }
}

/*void etat_capteur(char ref_e[],int etat)   //ok
{
    FILE* f;FILE* f0;
    int choix;
    capteur cap;
    f0=fopen("tmp.txt","w");
    f=fopen("fichier_capteur.txt","r");
    if(f!=NULL)
    {
        while(!feof(f))
        {
            fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %d %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,cap.etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee);
            if(ref_e!=cap.ref_cap)
            {
                fprintf(f0,"%s %s %d %d %d %s %d %d %d %d %d %d %d %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,cap.date_achat.jour,cap.date_achat.mois,cap.date_achat.annee,cap.etat,cap.sh.date_prise.jour,cap.sh.date_prise.mois,cap.sh.date_prise.annee,cap.sh.heure_prise.s,cap.sh.heure_prise.mm,cap.sh.heure_prise.hh,cap.sh.val,cap.val_min,cap.val_max,cap.pos.bloc,cap.pos.etage,cap.entretient.jour,cap.entretient.mois,cap.entretient.annee);
            }
            else
            {
                strcpy(cap.ref_cap,ref_e);
                if(etat==1)
                    strcpy(cap.etat,"ON");
                else if (etat==2)
                    strcpy(cap.etat,"OFF");
                else
                    strcpy(cap.etat,"PANNE");
                fprintf(f0,"%s %s %d %d %d %s %d %d %d %d %d %d %d %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,cap.date_achat.jour,cap.date_achat.mois,cap.date_achat.annee,cap.etat,cap.sh.date_prise.jour,cap.sh.date_prise.mois,cap.sh.date_prise.annee,cap.sh.heure_prise.s,cap.sh.heure_prise.mm,cap.sh.heure_prise.hh,cap.sh.val,cap.val_min,cap.val_max,cap.pos.bloc,cap.pos.etage,cap.entretient.jour,cap.entretient.mois,cap.entretient.annee);
            }
        }
        fclose(f);
        fclose(f0);
        remove("fichier_capteur.txt");
        rename("tmp.txt","fichier_capteur.txt");
    }
}

void afficher_capteur(char ref_r[])
{
    FILE* f;
    capteur cap;
    f=fopen("fichier_capteur.txt","r");
    if(f!=NULL)
    {
       while(!feof(f))
       {
           fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %d %d %d %s %d %d %d %d\n",
cap.ref_cap,cap.type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,cap.etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee);
           if(strcmp(ref_r,cap.ref_cap)==0){
                printf("\t\t\t\tREF: %s\n",cap.ref_cap);
                printf("\t\t\t\tType: %s\n",cap.type);
                printf("\t\t\t\tLocalisation :BLOC %s \n\t\t\t\t\t\tEtage: %d\n",cap.pos.bloc,cap.pos.etage);
                printf("\t\t\t  Etat: %s\n",cap.etat);
                printf("\t\t\t\Date d'entretient: %d/%d/%d\n",cap.entretient.jour,cap.entretient.mois,cap.entretient.annee);
                printf("\t\t\t\tla valeur de ce capteur doit etre dans [%d , %d]\n",cap.val_min,cap.val_max);
                printf("\t\t\t\tderniere valeur est = %d prise le %d/%d/%d  %d:%d:%d\n",
cap.sh.val,cap.sh.date_prise.jour,cap.sh.date_prise.mois,cap.sh.date_prise.annee,cap.sh.heure_prise.hh,cap.sh.heure_prise.mm,cap.sh.heure_prise.s);
                printf("\t\t\t\tDate d'achat: %d/%d/%d\n",cap.date_achat.jour,cap.date_achat.mois,cap.date_achat.annee);
                break;
           }
       }
       fclose(f);
    }
}*/

void afficher_par_bloc(GtkWidget *liste,char bloc[])
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque champs
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son variable de la liste
GtkTreeIter iter;
GtkListStore *store;


char ref[50];
char type[30];
char etat[10];
capteur cap;
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" ref",renderer,"text",Eref,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",Etype,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" etat",renderer,"text",Eetat,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("fichier_capteur.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("fichier_capteur.txt","a+");
while(fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
ref,type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee)
!=EOF)
{
if(strcmp(cap.pos.bloc,bloc)==0)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,Eref,ref,Etype,type,Eetat,etat,-1);
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
gtk_tree_view_get_selection(GTK_TREE_VIEW(liste));
g_object_unref(store);

}
}
//////////////////////////////////////////////////////////////////////////////

/*void
  treeview_popup_menu_supprimer (GtkWidget *menuitem, gpointer userdata,GtkTreePath *path)
  {
    GtkTreeIter iter;
 
    gchar* ref;  
    gchar* type;
    gchar* etat;

    /* we passed the view as userdata when we connected the signal */
/*    GtkTreeView *treeview = GTK_TREE_VIEW(userdata);
    GtkTreeModel *model =gtk_tree_view_get_model(treeview);



   
    if(gtk_tree_model_get_iter(model,&iter,path))
    {    
	  gtk_tree_model_get(model,&iter,Eref,ref,Etype,type,Eetat,etat,-1);
          g_print("ref");
    }   

  }




 void
  treeview_popup_menu_modifier (GtkWidget *menuitem, gpointer userdata,GtkTreePath *path)
  {
    GtkTreeIter iter;
  
    gchar* ref;  
    gchar* type;
    gchar* etat;
    /* we passed the view as userdata when we connected the signal */
/*    GtkTreeView *treeview = GTK_TREE_VIEW(userdata);
    GtkTreeModel *model =gtk_tree_view_get_model(treeview);
   
    if(gtk_tree_model_get_iter(model,&iter,path))
    {    
	  gtk_tree_model_get(model,&iter,Eref,ref,Etype,type,Eetat,etat,-1);
          g_print("sss");
    }   

  }


  void
  treeview_popup_menu (GtkWidget *treeview, GdkEventButton *event, gpointer userdata,GtkTreePath *path)
  {
    GtkWidget *menu, *menuitem_mod,*menuitem_supp;

    menu = gtk_menu_new();

    menuitem_mod = gtk_menu_item_new_with_label("Modifier");

    g_signal_connect(menuitem_mod, "activate",
                     (GCallback) treeview_popup_menu_modifier, treeview);

    gtk_menu_shell_append(GTK_MENU_SHELL(menu), menuitem_mod);


    menuitem_supp = gtk_menu_item_new_with_label("Supprimer");

    g_signal_connect(menuitem_supp, "activate",
                     (GCallback) treeview_popup_menu_supprimer, treeview);

    gtk_menu_shell_append(GTK_MENU_SHELL(menu), menuitem_supp);

    gtk_widget_show_all(menu);

    /* Note: event can be NULL here when called from view_onPopupMenu;
     *  gdk_event_get_time() accepts a NULL argument */
/*    gtk_menu_popup(GTK_MENU(menu), NULL, NULL, NULL, NULL,
                   (event != NULL) ? event->button : 0,
                   gdk_event_get_time((GdkEvent*)event));
  }




*/




//////////////////////////////////////////////////////////////////////
/*void selection()
{
GtkTreeSelection *select;
GtkTreeModel     *model;
GtkTreeIter       iter;

select= gtk_tree_view_get_selection(GTK_TREE_VIEW(view));
if(gtk_tree_selection_get_selected(selection,&model,&iter))
{
	gchar *ref;
	gchar *type;
	gchar *etat;
	gtk_tree_model_get(model,&iter,Eref,ref,Etype,type,Eetat,etat,-1);
	
}
}*/


void afficher_on(GtkWidget *liste,char bloc[])
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque champs
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son variable de la liste
GtkTreeIter iter;
GtkListStore *store;

char ref[50];
char type[30];
char etat[10];
capteur cap;
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" ref",renderer,"text",Eref,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",Etype,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" etat",renderer,"text",Eetat,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("fichier_capteur.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("fichier_capteur.txt","a+");
while(fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
ref,type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee)
!=EOF)
{
if((strcmp(cap.pos.bloc,bloc)==0)&&(strcmp(etat,"ON")==0))
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,Eref,ref,Etype,type,Eetat,etat,-1);
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}





void afficher_off(GtkWidget *liste,char bloc[])
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque champs
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son variable de la liste
GtkTreeIter iter;
GtkListStore *store;

char ref[50];
char type[30];
char etat[10];
capteur cap;
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" ref",renderer,"text",Eref,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",Etype,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" etat",renderer,"text",Eetat,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("fichier_capteur.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("fichier_capteur.txt","a+");
while(fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
ref,type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee)
!=EOF)
{
if((strcmp(cap.pos.bloc,bloc)==0)&&(strcmp(etat,"OFF")==0))
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,Eref,ref,Etype,type,Eetat,etat,-1);
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}



void afficher_panne(GtkWidget *liste,char bloc[])
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque champs
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son variable de la liste
GtkTreeIter iter;
GtkListStore *store;

char ref[50];
char type[30];
char etat[10];
capteur cap;
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" ref",renderer,"text",Eref,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",Etype,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" etat",renderer,"text",Eetat,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("fichier_capteur.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("fichier_capteur.txt","a+");
while(fscanf(f,"%s %s %d %d %d %s %d %d %d %d %d %d %f %d %d %s %d %d %d %d\n",
ref,type,&cap.date_achat.jour,&cap.date_achat.mois,&cap.date_achat.annee,etat,&cap.sh.date_prise.jour,&cap.sh.date_prise.mois,&cap.sh.date_prise.annee,&cap.sh.heure_prise.s,&cap.sh.heure_prise.mm,&cap.sh.heure_prise.hh,&cap.sh.val,&cap.val_min,&cap.val_max,cap.pos.bloc,&cap.pos.etage,&cap.entretient.jour,&cap.entretient.mois,&cap.entretient.annee)
!=EOF)
{
if((strcmp(cap.pos.bloc,bloc)==0)&&(strcmp(etat,"PANNE")==0))
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,Eref,ref,Etype,type,Eetat,etat,-1);
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}


void vider(GtkWidget *liste)
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque champs
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son variable de la liste
GtkTreeIter iter;
GtkListStore *store;

char ref[50];
char type[30];
char etat[10];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" ref",renderer,"text",Eref,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",Etype,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" etat",renderer,"text",Eetat,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
gtk_list_store_append(store,&iter);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));

}

enum
{
	TYPE,
	NUM,
	JOUR,
	HEURE,
	VAL,
	COLUMNSS
};


void afficher_alarme(GtkWidget *liste)
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son var
GtkTreeIter iter;
GtkListStore *store;

int num;
int jour;
int heure;
int val;
char type[30];
alarme al;
store=NULL;

FILE *fm;
FILE *ff;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" num",renderer,"text",NUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" heure",renderer,"text",HEURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" val",renderer,"text",VAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

ff=fopen("Fumee.txt","r");
fm=fopen("mouvement.txt","r");
if(ff==NULL)
{
return;
}
else
{
ff=fopen("Fumee.txt","a+");
while(fscanf(ff,"%d %d %d %d \n",&jour,&heure,&num,&val)!=EOF)
{
if(val==1)
{
strcpy(type,"Fumee");
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE,type,NUM,num,JOUR,jour,HEURE,heure,VAL,val,-1);
}
}
fclose(ff);
//gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
//g_object_unref(store);
}


if(fm==NULL)
{
return;
}
else
{
fm=fopen("mouvement.txt","a+");
while(fscanf(fm,"%d %d %d %d \n",&jour,&heure,&num,&val)!=EOF)
{
if(val==1)
{
strcpy(type,"Mouvement");
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE,type,NUM,num,JOUR,jour,HEURE,heure,VAL,val,-1);
}
}
fclose(fm);
//gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
//g_object_unref(store);
}
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);

}


void afficher_fumee_alarme(GtkWidget *liste)
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son var
GtkTreeIter iter;
GtkListStore *store;

int num;
int jour;
int heure;
int val;
char type[30];
alarme al;
store=NULL;

FILE *ff;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" num",renderer,"text",NUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" heure",renderer,"text",HEURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" val",renderer,"text",VAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

ff=fopen("Fumee.txt","r");
if(ff==NULL)
{
return;
}
else
{
ff=fopen("Fumee.txt","a+");
while(fscanf(ff,"%d %d %d %d \n",&jour,&heure,&num,&val)!=EOF)
{
if(val==1)
{
strcpy(type,"Fumee");
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE,type,NUM,num,JOUR,jour,HEURE,heure,VAL,val,-1);
}
}
fclose(ff);
}

gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}

void afficher_mouv_alarme(GtkWidget *liste)
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son var
GtkTreeIter iter;
GtkListStore *store;

int num;
int jour;
int heure;
int val;
char type[30];
alarme al;
store=NULL;

FILE *fm;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" num",renderer,"text",NUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" heure",renderer,"text",HEURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" val",renderer,"text",VAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);


fm=fopen("mouvement.txt","r");

if(fm==NULL)
{
return;
}
else
{
fm=fopen("mouvement.txt","a+");
while(fscanf(fm,"%d %d %d %d \n",&jour,&heure,&num,&val)!=EOF)
{
if(val==1)
{
strcpy(type,"Mouvement");
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE,type,NUM,num,JOUR,jour,HEURE,heure,VAL,val,-1);
}
}
fclose(fm);
}
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}


void supprimer_alarme(alarme al,char type[])
{
int num;
int jour;
int heure;
int val;

FILE *f,*g;
if(strcmp(type,"Fumee")==0)
{
f=fopen("Fumee.txt","r");
g=fopen("dump.txt","w");
if(f==NULL || g==NULL)
{
return;
}
else
{
while(fscanf(f,"%d %d %d %d \n",&jour,&heure,&num,&val)!=EOF)
{
if((al.num==num)||(al.jour==jour)||(al.heure==heure)||(al.val==val))
fprintf(g,"%d %d %d %d \n",jour,heure,num,val);
}
fclose(f);
fclose(g);
remove("Fumee.txt");
rename("dump.txt","Fumee.txt");
}
}
else if (strcmp(type,"Mouvement")==0)
{
f=fopen("mouvement.txt","r");
g=fopen("dump.txt","w");
if(f==NULL || g==NULL)
{
return;
}
else
{
while(fscanf(f,"%d %d %d %d \n",&jour,&heure,&num,&val)!=EOF)
{
if((al.num==num)||(al.jour==jour)||(al.heure==heure)||(al.val==val))
fprintf(g,"%d %d %d %d \n",jour,heure,num,val);
}
fclose(f);
fclose(g);
remove("mouvement.txt");
rename("dump.txt","mouvement.txt");
}
}
}


void vider_alarme(GtkWidget *liste)
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque champs
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son variable de la 
GtkTreeIter iter;
GtkListStore *store;

int num;
int jour;
int heure;
int val;
char type[30];
alarme al;
store=NULL;

FILE *fm;
FILE *ff;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" num",renderer,"text",NUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" heure",renderer,"text",HEURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" val",renderer,"text",VAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
gtk_list_store_append(store,&iter);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
}


void afficher_temperature(GtkWidget *liste)
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son var
GtkTreeIter iter;
GtkListStore *store;

int num;
int jour;
int heure;
float val;
char type[30];
alarme al;
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" num",renderer,"text",NUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" heure",renderer,"text",HEURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" val",renderer,"text",VAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_FLOAT);

f=fopen("temperature.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("temperature.txt","a+");
while(fscanf(f,"%d %d %d %f \n",&jour,&heure,&num,&val)!=EOF)
{
if((val<10)||(val>30))
{
strcpy(type,"Temperature");
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE,type,NUM,num,JOUR,jour,HEURE,heure,VAL,val,-1);
}
}
fclose(f);
}
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}


void supprimer_temperature(temperature temp)
{
int num;
int jour;
int heure;
float val;

FILE *f,*g;
f=fopen("temperature.txt","r");
g=fopen("dump.txt","w");
if(f==NULL || g==NULL)
{
return;
}
else
{
while(fscanf(f,"%d %d %d %f \n",&jour,&heure,&num,&val)!=EOF)
{
if((temp.num==num)||(temp.jour==jour)||(temp.heure==heure)||(temp.val==val))
fprintf(g,"%d %d %d %f \n",jour,heure,num,val);
}
fclose(f);
fclose(g);
remove("temperature.txt");
rename("dump.txt","temperature.txt");
}
}

/*
void vider_temperature(GtkWidget *liste)
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque champs
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son variable de la 
GtkTreeIter iter;
GtkListStore *store;

int num;
int jour;
int heure;
float val;
char type[30];
alarme al;
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" num",renderer,"text",NUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" heure",renderer,"text",HEURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" val",renderer,"text",VAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_FLOAT);
gtk_list_store_append(store,&iter);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
}*/
