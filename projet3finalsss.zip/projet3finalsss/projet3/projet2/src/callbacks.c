#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include <string.h>

capteur cap;



void
on_button56_ajoutercapteur_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *ref;
GtkWidget *type;
GtkWidget *j_achat;
GtkWidget *m_achat;
GtkWidget *a_achat;
GtkWidget *j_entretient;
GtkWidget *m_entretient;
GtkWidget *a_entretient;
GtkWidget *val_max;
GtkWidget *val_min;
GtkWidget *val;
GtkWidget *j_val;
GtkWidget *m_val;
GtkWidget *a_val;
GtkWidget *h_val;
GtkWidget *min_val;
GtkWidget *s_val;
GtkWidget *bloc;
GtkWidget *etage;
GtkWidget *msg;
//GtkAdjustment *adjustment_val;

//associer les objets avec des variables

ref=lookup_widget(objet_graphique,"entry4_ref");//ok
type=lookup_widget(objet_graphique,"comboboxentry2_type");//ok
j_achat=lookup_widget(objet_graphique,"jour_achat");//ok
m_achat=lookup_widget(objet_graphique,"mois_achat");//ok
a_achat=lookup_widget(objet_graphique,"spinbutton4_annee_achat");//ok
j_entretient=lookup_widget(objet_graphique,"spinbutton11_jour_entretient");//ok
m_entretient=lookup_widget(objet_graphique,"spinbutton12_mois_entretient");//ok
a_entretient=lookup_widget(objet_graphique,"spinbutton13_annee_entretient");//ok
val_max=lookup_widget(objet_graphique,"spinbutton27_max_val");
val_min=lookup_widget(objet_graphique,"spinbutton28_min_val");
val=lookup_widget(objet_graphique,"hscale_val");
j_val=lookup_widget(objet_graphique,"spinbutton8_valeur_jour");//ok
m_val=lookup_widget(objet_graphique,"spinbutton9_valeur_mois");//ok
a_val=lookup_widget(objet_graphique,"spinbutton10_valeur_annee");//ok
h_val=lookup_widget(objet_graphique,"spinbutton29_heure");//ok
min_val=lookup_widget(objet_graphique,"spinbutton28_min");//ok
s_val=lookup_widget(objet_graphique,"spinbutton27_sec");//ok
bloc=lookup_widget(objet_graphique,"comboboxentry1_bloc");//ok
etage=lookup_widget(objet_graphique,"spinbutton1_etage");//ok
msg=lookup_widget(objet_graphique,"label154_msg");

//entry
strcpy(cap.ref_cap,gtk_entry_get_text(GTK_ENTRY(ref)));
//recuperer les valeurs des spin buttons 
cap.date_achat.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j_achat));
cap.date_achat.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m_achat));
cap.date_achat.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a_achat));
cap.entretient.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j_entretient));
cap.entretient.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m_entretient));
cap.entretient.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a_entretient));
cap.val_max=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val_max));
cap.val_min=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val_min));
cap.sh.date_prise.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j_val));
cap.sh.date_prise.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m_val));
cap.sh.date_prise.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a_val));
cap.sh.heure_prise.hh=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(h_val));
cap.sh.heure_prise.mm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min_val));
cap.sh.heure_prise.s=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(s_val));
cap.pos.etage=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etage));

//val entre [min,max] dans le button ajuster
//adjustment_val=gtk_adjustment_new((float)cap.val_min, (float)cap.val_min, (float)cap.val_max,0.5,2.0,0.0);
//gtk_range_set_adjustment(GTK_RANGE(val),adjustment_val);
//recup hscale
cap.sh.val=gtk_range_get_value(GTK_RANGE(val));

//recuperer les valeurs des combobox
strcpy(cap.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(cap.pos.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(bloc)));

//remplir le fichier_capteur
ajouter_capteur(cap);

//message
//gras ok
gchar* sUtf8;
sUtf8=g_locale_to_utf8("<span face=\"sss\"><b>Votre capteur est bien ajouter</b></span>",-1,NULL,NULL,NULL);
gtk_label_set_markup(GTK_LABEL(msg),sUtf8);
//gtk_label_set_text(GTK_LABEL(msg),"Votre capteur est bien ajouter");

}

void
on_radiobutton2_off_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
//ok
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	strcpy(cap.etat,"OFF");
}

void
on_radiobutton1_on_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
//ok
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	strcpy(cap.etat,"ON");
}

void
on_button57_annuler_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
//ok
GtkWidget *window_liste;
GtkWidget *window_ajout;

window_liste =create_liste_capteur ();
gtk_widget_show (window_liste);

window_ajout=lookup_widget(objet,"Ajouter_capteur");
gtk_widget_destroy(window_ajout);
}



void
on_button69_afficher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_afficher;
GtkWidget *window_liste;

window_afficher =create_capteur();
gtk_widget_show (window_afficher);

window_liste=lookup_widget(objet,"liste_capteur");
gtk_widget_destroy(window_liste);
}


void
on_button67_modifier_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_modifier;
GtkWidget *window_liste;

window_modifier =create_modifier2_capteur ();
gtk_widget_show (window_modifier);

window_liste=lookup_widget(objet,"liste_capteur");
gtk_widget_destroy(window_liste);
}


void
on_button66_ajouter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter;
GtkWidget *window_liste;

window_ajouter =create_Ajouter_capteur ();
gtk_widget_show (window_ajouter);

window_liste=lookup_widget(objet,"liste_capteur");
gtk_widget_destroy(window_liste);
}


void
on_button68_supprimer_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_supprimer;
GtkWidget *window_liste;

window_supprimer =create_supprimer_capteur ();
gtk_widget_show (window_supprimer);

window_liste=lookup_widget(objet,"liste_capteur");
gtk_widget_destroy(window_liste);
}


void
on_button66_chercher_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
//ok
//ne9es yet3amrou auto w blocage
GtkWidget *ref;
int test;
GtkWidget *msg;
GtkWidget *type;
GtkWidget *j_achat;
GtkWidget *m_achat;
GtkWidget *a_achat;
GtkWidget *j_entretient;
GtkWidget *m_entretient;
GtkWidget *a_entretient;
GtkWidget *val_max;
GtkWidget *val_min;
GtkWidget *val;
GtkWidget *j_val;
GtkWidget *m_val;
GtkWidget *a_val;
GtkWidget *h_val;
GtkWidget *min_val;
GtkWidget *s_val;
GtkWidget *bloc;
GtkWidget *etage;
GtkWidget *on;
GtkWidget *off;
GtkWidget *panne;
GtkAdjustment *adjustment_val;
GtkWidget *window_liste;

window_liste=lookup_widget(objet_graphique,"liste_capteur");
gtk_widget_destroy(window_liste);

ref=lookup_widget(objet_graphique,"entry6_ref");
type=lookup_widget(objet_graphique,"comboboxentry2_type");//ok
j_achat=lookup_widget(objet_graphique,"spinbutton14_j_achat");//ok
m_achat=lookup_widget(objet_graphique,"spinbutton15_m_achat");//ok
a_achat=lookup_widget(objet_graphique,"spinbutton16_a_achat");//ok
j_entretient=lookup_widget(objet_graphique,"spinbutton17_j_entretien");//ok
m_entretient=lookup_widget(objet_graphique,"spinbutton18_m_entretien");//ok
a_entretient=lookup_widget(objet_graphique,"spinbutton19_a_entretien");//ok
val_max=lookup_widget(objet_graphique,"spinbutton29_val_max");
val_min=lookup_widget(objet_graphique,"spinbutton30_val_min");
val=lookup_widget(objet_graphique,"hscale_modif");//ok
j_val=lookup_widget(objet_graphique,"spinbutton23_j_val");//ok
m_val=lookup_widget(objet_graphique,"spinbutton24_m_val");//ok
a_val=lookup_widget(objet_graphique,"spinbutton25_a_val");//ok
h_val=lookup_widget(objet_graphique,"spinbutton33_h_val");//ok
min_val=lookup_widget(objet_graphique,"spinbutton32_m_val");//ok
s_val=lookup_widget(objet_graphique,"spinbutton31_s_val");//ok
bloc=lookup_widget(objet_graphique,"comboboxentry4_bloc");//ok
etage=lookup_widget(objet_graphique,"spinbutton26_etage");
on=lookup_widget(objet_graphique,"radiobutton3_on");
off=lookup_widget(objet_graphique,"radiobutton4_off");
panne=lookup_widget(objet_graphique,"radiobutton5_panne");

msg=lookup_widget(objet_graphique,"label160_msg");
strcpy(cap.ref_cap,gtk_entry_get_text(GTK_ENTRY(ref)));
test=verifier_capteur(cap.ref_cap);
if (test==1)
{
cap=recherche(cap.ref_cap);
//affichage
//combo
if(strcmp(cap.type,"Temperature")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(type),0);
}
else if(strcmp(cap.type,"Debit_d'eau")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(type),1);
}
else if(strcmp(cap.type,"Detecteur_mouvement")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(type),2);
}
else if(strcmp(cap.type,"Fumee")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(type),3);
}
else if(strcmp(cap.type,"Dechet")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(type),4);
}
//etage

if(strcmp(cap.pos.bloc,"A")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),0);
}
else if(strcmp(cap.pos.bloc,"B")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),1);
}
else if(strcmp(cap.pos.bloc,"C")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),2);
}
else if(strcmp(cap.pos.bloc,"D")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),3);
}
else if(strcmp(cap.pos.bloc,"E")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),4);
}
else if(strcmp(cap.pos.bloc,"G")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),5);
}
else if(strcmp(cap.pos.bloc,"I")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),6);
}
else if(strcmp(cap.pos.bloc,"J")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),7);
}
else if(strcmp(cap.pos.bloc,"K")==0){
gtk_combo_box_set_active(GTK_COMBO_BOX(bloc),8);
}


//spin ok :) :)
gtk_spin_button_set_value(j_achat,cap.date_achat.jour);
gtk_spin_button_set_value(m_achat,cap.date_achat.mois);
gtk_spin_button_set_value(a_achat,cap.date_achat.annee);
gtk_spin_button_set_value(j_entretient,cap.entretient.jour);
gtk_spin_button_set_value(m_entretient,cap.entretient.mois);
gtk_spin_button_set_value(a_entretient,cap.entretient.annee);
gtk_spin_button_set_value(val_max,cap.val_max);
gtk_spin_button_set_value(val_min,cap.val_min);
gtk_spin_button_set_value(j_val,cap.sh.date_prise.jour);
gtk_spin_button_set_value(m_val,cap.sh.date_prise.mois);
gtk_spin_button_set_value(a_val,cap.sh.date_prise.annee);
gtk_spin_button_set_value(h_val,cap.sh.heure_prise.hh);
gtk_spin_button_set_value(min_val,cap.sh.heure_prise.mm);
gtk_spin_button_set_value(s_val,cap.sh.heure_prise.s);
gtk_spin_button_set_value(etage,cap.pos.etage);



//radio  ok :) :)
if(strcmp(cap.etat,"ON")==0)
	gtk_toggle_button_set_active(on,1);
else if(strcmp(cap.etat,"OFF")==0)
	gtk_toggle_button_set_active(off,1);
else if(strcmp(cap.etat,"PANNE")==0)
	gtk_toggle_button_set_active(panne,1);




//hscale
adjustment_val=gtk_adjustment_new(cap.sh.val, (float)cap.val_min, (float)cap.val_max,0.5,2.0,0.0);
//val entre [min,max]
gtk_range_set_adjustment(GTK_RANGE(val),adjustment_val); 

gtk_label_set_text(GTK_LABEL(msg),"Ce capteur existe vous pouvez le modifier :)");
//debloquer les widgets
}
else if(test==0)
{
gtk_label_set_text(GTK_LABEL(msg),"Ce capteur n'existe pas :(");
//bloquer les widgets
//spin
/*gtk_spin_button_set_editable(GTK_SPIN_BUTTON(j_achat),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(m_achat),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(a_achat),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(j_entretient),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(m_entretient),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(a_entretient),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(val_max),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(val_min),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(j_val),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(m_val),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(a_val),FALSE);
gtk_spin_button_set_ediatble(GTK_SPIN_BUTTON(h_val),FALSE);
gtk_spin_button_set_ediatble(GTK_SPIN_BUTTON(min_val),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(s_val),FALSE);
gtk_spin_button_set_editable(GTK_SPIN_BUTTON(etage),FALSE);
*/
}
}

void
on_button66_chercher_ajouter_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
//ok
//ne9es blocage w deblocage
GtkWidget *ref;
int test;
GtkWidget *msg;
ref=lookup_widget(objet_graphique,"entry4_ref");
msg=lookup_widget(objet_graphique,"label161_msg");
strcpy(cap.ref_cap,gtk_entry_get_text(GTK_ENTRY(ref)));
test=verifier_capteur(cap.ref_cap);
if (test==1)
{
gtk_label_set_text(GTK_LABEL(msg),"Ce capteur existe deja !!!");
//debloquer les widgets
}
else if(test==0)
{
gtk_label_set_text(GTK_LABEL(msg),"Ce capteur n'existe pas Vous pouvez l'ajouter");
//bloquer les widgets

}
}

void
on_button60_mod_cap_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
//ok
GtkWidget *ref;
GtkWidget *type;
GtkWidget *j_achat;
GtkWidget *m_achat;
GtkWidget *a_achat;
GtkWidget *j_entretient;
GtkWidget *m_entretient;
GtkWidget *a_entretient;
GtkWidget *val_max;
GtkWidget *val_min;
GtkWidget *val;
GtkWidget *j_val;
GtkWidget *m_val;
GtkWidget *a_val;
GtkWidget *h_val;
GtkWidget *min_val;
GtkWidget *s_val;
GtkWidget *bloc;
GtkWidget *etage;
GtkWidget *msg;

ref=lookup_widget(objet_graphique,"entry6_ref");
type=lookup_widget(objet_graphique,"comboboxentry2_type");//ok
j_achat=lookup_widget(objet_graphique,"spinbutton14_j_achat");//ok
m_achat=lookup_widget(objet_graphique,"spinbutton15_m_achat");//ok
a_achat=lookup_widget(objet_graphique,"spinbutton16_a_achat");//ok
j_entretient=lookup_widget(objet_graphique,"spinbutton17_j_entretien");//ok
m_entretient=lookup_widget(objet_graphique,"spinbutton18_m_entretien");//ok
a_entretient=lookup_widget(objet_graphique,"spinbutton19_a_entretien");//ok
val_max=lookup_widget(objet_graphique,"spinbutton29_val_max");
val_min=lookup_widget(objet_graphique,"spinbutton30_val_min");
val=lookup_widget(objet_graphique,"hscale_modif");//ok
j_val=lookup_widget(objet_graphique,"spinbutton23_j_val");//ok
m_val=lookup_widget(objet_graphique,"spinbutton24_m_val");//ok
a_val=lookup_widget(objet_graphique,"spinbutton25_a_val");//ok
h_val=lookup_widget(objet_graphique,"spinbutton33_h_val");//ok
min_val=lookup_widget(objet_graphique,"spinbutton32_m_val");//ok
s_val=lookup_widget(objet_graphique,"spinbutton31_s_val");//ok
bloc=lookup_widget(objet_graphique,"comboboxentry4_bloc");//ok
etage=lookup_widget(objet_graphique,"spinbutton26_etage");
msg=lookup_widget(objet_graphique,"label_modif");

strcpy(cap.ref_cap,gtk_entry_get_text(GTK_ENTRY(ref)));
cap.date_achat.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j_achat));
cap.date_achat.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m_achat));
cap.date_achat.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a_achat));
cap.entretient.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j_entretient));
cap.entretient.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m_entretient));
cap.entretient.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a_entretient));
//cap.sh.val=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val));
cap.val_max=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val_max));
cap.val_min=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val_min));
cap.sh.date_prise.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j_val));
cap.sh.date_prise.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m_val));
cap.sh.date_prise.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a_val));
cap.sh.heure_prise.hh=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(h_val));
cap.sh.heure_prise.mm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min_val));
cap.sh.heure_prise.s=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(s_val));
cap.pos.etage=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etage));

//recuperer les valeurs des combobox
strcpy(cap.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(cap.pos.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(bloc)));

//recup hscale
//ok
cap.sh.val=gtk_range_get_value(GTK_RANGE(val));


modifier_capteur(cap);


//message
//gras ok
gchar* sUtf8;
sUtf8=g_locale_to_utf8("<span face=\"sss\"><b>Votre capteur est bien modifier</b></span>",-1,NULL,NULL,NULL);
gtk_label_set_markup(GTK_LABEL(msg),sUtf8);
}


void
on_radiobutton5_panne_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	strcpy(cap.etat,"PANNE");
}



void
on_radiobutton4_off_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	strcpy(cap.etat,"OFF");
}



void
on_radiobutton3_on_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	strcpy(cap.etat,"ON");
}


void
on_button61_r_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
//ok
GtkWidget *window_liste;
GtkWidget *window_modif;

window_liste =create_liste_capteur ();
gtk_widget_show (window_liste);

window_modif=lookup_widget(objet,"modifier2_capteur");
gtk_widget_destroy(window_modif);
}


void
on_button65_retour_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
//ok
GtkWidget *window_liste;
GtkWidget *window_supp;

window_liste =create_liste_capteur ();
gtk_widget_show (window_liste);

window_supp=lookup_widget(objet,"supprimer_capteur");
gtk_widget_destroy(window_supp);
}

int test_check=0;
void
on_button64_conf_supp_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
//ok
GtkWidget *ref;
int test;
GtkWidget *msg;
ref=lookup_widget(objet_graphique,"entry8_supp");
msg=lookup_widget(objet_graphique,"label164_supp");

strcpy(cap.ref_cap,gtk_entry_get_text(GTK_ENTRY(ref)));
test=verifier_capteur(cap.ref_cap);

if(test==0)
{
gtk_label_set_text(GTK_LABEL(msg),"Ce capteur n'existe pas ou deja supprimer");
}

if ((test==1)&&(test_check==1))
{
supprimer_capteur(cap.ref_cap);
gtk_label_set_text(GTK_LABEL(msg),"Capteur supprimer avec succes :)");
}
}

void
on_treeview12_blocA_row_activated            (
					GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
  //obtention des valeurs de la ligne selectionnee
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
  //supprimer_capteur(cap.ref_cap);
  afficher_par_bloc(treeview,"A");
//g_signal_connect(treeview, "button-press-event", (GCallback) on_treeview12_button_press_event, NULL);
//g_signal_connect(treeview, "popup-menu", (GCallback) on_treeview12_popup_menu, NULL);
//selection();
//if(gtk_tree_model_get_iter(model,&iter,path)
//{
//  gtk_tree_model_get(model,&iter,Eref,ref,Etype,type,Eetat,etat,-1);
  
//}

}

}

void
on_treeview13_blocB_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;


GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
//supprimer_capteur(cap.ref_cap);
afficher_par_bloc(treeview,"B");
}
}


void
on_treeview14_blocC_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
//supprimer_capteur(cap.ref_cap);
 afficher_par_bloc(treeview,"C");
}
}


void
on_treeview15_blocD_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;


GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
//supprimer_capteur(cap.ref_cap);
afficher_par_bloc(treeview,"D");
}
}


void
on_treeview16_blocE_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
//supprimer_capteur(cap.ref_cap);
afficher_par_bloc(treeview,"E");
}
}


void
on_treeview17_blocG_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
//supprimer_capteur(cap.ref_cap);
afficher_par_bloc(treeview,"G");
}
}


void
on_treeview18_blocI_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
//supprimer_capteur(cap.ref_cap);
afficher_par_bloc(treeview,"I");
}
}


void
on_treeview19_blocJ_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
//supprimer_capteur(cap.ref_cap);
afficher_par_bloc(treeview,"J");
}
}


void
on_treeview20_blocK_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* type;
gchar* etat;
capteur cap;
GtkWidget *window_modifier;
GtkWidget *ref_s;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{
  gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&type,2,&etat,-1);
  strcpy(cap.ref_cap,ref);
  strcpy(cap.type,type);
  strcpy(cap.etat,etat);
  window_modifier =create_modifier2_capteur ();
  ref_s=lookup_widget(G_OBJECT(window_modifier),"entry6_ref");
  gtk_widget_show (window_modifier);
  gtk_entry_set_text(GTK_ENTRY(ref_s),cap.ref_cap);
//supprimer_capteur(cap.ref_cap);
afficher_par_bloc(treeview,"K");
}
}


void
on_button_panne_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_liste,*w1;
GtkWidget *treeview12,*treeview13,*treeview14,*treeview15,*treeview16,*treeview17,*treeview18,*treeview19,*treeview20;

w1=lookup_widget(objet,"liste_capteur");
window_liste =create_liste_capteur ();

gtk_widget_show(window_liste);

gtk_widget_hide(w1);
treeview12=lookup_widget(window_liste,"treeview12_blocA");
treeview13=lookup_widget(window_liste,"treeview13_blocB");
treeview14=lookup_widget(window_liste,"treeview14_blocC");
treeview15=lookup_widget(window_liste,"treeview15_blocD");
treeview16=lookup_widget(window_liste,"treeview16_blocE");
treeview17=lookup_widget(window_liste,"treeview17_blocG");
treeview18=lookup_widget(window_liste,"treeview18_blocI");
treeview19=lookup_widget(window_liste,"treeview19_blocJ");
treeview20=lookup_widget(window_liste,"treeview20_blocK");

vider(treeview12);
vider(treeview13);
vider(treeview14);
vider(treeview15);
vider(treeview16);
vider(treeview17);
vider(treeview18);
vider(treeview19);
vider(treeview20);
afficher_panne(treeview12,"A");
afficher_panne(treeview13,"B");
afficher_panne(treeview14,"C");
afficher_panne(treeview15,"D");
afficher_panne(treeview16,"E");
afficher_panne(treeview17,"G");
afficher_panne(treeview18,"I");
afficher_panne(treeview19,"J");
afficher_panne(treeview20,"K");
}


void
on_button_off_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_liste,*w1;
GtkWidget *treeview12,*treeview13,*treeview14,*treeview15,*treeview16,*treeview17,*treeview18,*treeview19,*treeview20;

w1=lookup_widget(objet,"liste_capteur");
window_liste =create_liste_capteur ();

gtk_widget_show(window_liste);

gtk_widget_hide(w1);
treeview12=lookup_widget(window_liste,"treeview12_blocA");
treeview13=lookup_widget(window_liste,"treeview13_blocB");
treeview14=lookup_widget(window_liste,"treeview14_blocC");
treeview15=lookup_widget(window_liste,"treeview15_blocD");
treeview16=lookup_widget(window_liste,"treeview16_blocE");
treeview17=lookup_widget(window_liste,"treeview17_blocG");
treeview18=lookup_widget(window_liste,"treeview18_blocI");
treeview19=lookup_widget(window_liste,"treeview19_blocJ");
treeview20=lookup_widget(window_liste,"treeview20_blocK");

vider(treeview12);
vider(treeview13);
vider(treeview14);
vider(treeview15);
vider(treeview16);
vider(treeview17);
vider(treeview18);
vider(treeview19);
vider(treeview20);
afficher_off(treeview12,"A");
afficher_off(treeview13,"B");
afficher_off(treeview14,"C");
afficher_off(treeview15,"D");
afficher_off(treeview16,"E");
afficher_off(treeview17,"G");
afficher_off(treeview18,"I");
afficher_off(treeview19,"J");
afficher_off(treeview20,"K");
}


void
on_button_on_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_liste,*w1;
GtkWidget *treeview12,*treeview13,*treeview14,*treeview15,*treeview16,*treeview17,*treeview18,*treeview19,*treeview20;

w1=lookup_widget(objet,"liste_capteur");
window_liste =create_liste_capteur ();

gtk_widget_show(window_liste);

gtk_widget_hide(w1);
treeview12=lookup_widget(window_liste,"treeview12_blocA");
treeview13=lookup_widget(window_liste,"treeview13_blocB");
treeview14=lookup_widget(window_liste,"treeview14_blocC");
treeview15=lookup_widget(window_liste,"treeview15_blocD");
treeview16=lookup_widget(window_liste,"treeview16_blocE");
treeview17=lookup_widget(window_liste,"treeview17_blocG");
treeview18=lookup_widget(window_liste,"treeview18_blocI");
treeview19=lookup_widget(window_liste,"treeview19_blocJ");
treeview20=lookup_widget(window_liste,"treeview20_blocK");

vider(treeview12);
vider(treeview13);
vider(treeview14);
vider(treeview15);
vider(treeview16);
vider(treeview17);
vider(treeview18);
vider(treeview19);
vider(treeview20);
afficher_on(treeview12,"A");
afficher_on(treeview13,"B");
afficher_on(treeview14,"C");
afficher_on(treeview15,"D");
afficher_on(treeview16,"E");
afficher_on(treeview17,"G");
afficher_on(treeview18,"I");
afficher_on(treeview19,"J");
afficher_on(treeview20,"K");
}


void
on_button_liste_capteur_actualiser_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
//ok
GtkWidget *window_liste,*w1;
GtkWidget *treeview12,*treeview13,*treeview14,*treeview15,*treeview16,*treeview17,*treeview18,*treeview19,*treeview20;

w1=lookup_widget(objet,"liste_capteur");
window_liste =create_liste_capteur ();

gtk_widget_show(window_liste);

gtk_widget_hide(w1);
treeview12=lookup_widget(window_liste,"treeview12_blocA");
treeview13=lookup_widget(window_liste,"treeview13_blocB");
treeview14=lookup_widget(window_liste,"treeview14_blocC");
treeview15=lookup_widget(window_liste,"treeview15_blocD");
treeview16=lookup_widget(window_liste,"treeview16_blocE");
treeview17=lookup_widget(window_liste,"treeview17_blocG");
treeview18=lookup_widget(window_liste,"treeview18_blocI");
treeview19=lookup_widget(window_liste,"treeview19_blocJ");
treeview20=lookup_widget(window_liste,"treeview20_blocK");

vider(treeview12);
vider(treeview13);
vider(treeview14);
vider(treeview15);
vider(treeview16);
vider(treeview17);
vider(treeview18);
vider(treeview19);
vider(treeview20);
afficher_par_bloc(treeview12,"A");
afficher_par_bloc(treeview13,"B");
afficher_par_bloc(treeview14,"C");
afficher_par_bloc(treeview15,"D");
afficher_par_bloc(treeview16,"E");
afficher_par_bloc(treeview17,"G");
afficher_par_bloc(treeview18,"I");
afficher_par_bloc(treeview19,"J");
afficher_par_bloc(treeview20,"K");
}

//ok :) :)
void
on_ajuster_aj_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *val_max;
GtkWidget *val_min;
GtkWidget *val;
GtkAdjustment *adjustment_val;
int min,max;

val=lookup_widget(objet_graphique,"hscale_val");
val_max=lookup_widget(objet_graphique,"spinbutton27_max_val");
val_min=lookup_widget(objet_graphique,"spinbutton28_min_val");

//lire les deux valeurs de max et min
max=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val_max));
min=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val_min));

//ajuster
adjustment_val=gtk_adjustment_new((float)min, (float)min, (float)max,0.5,2.0,0.0);
gtk_range_set_adjustment(GTK_RANGE(val),adjustment_val);
}


void
on_treeview21_alarme_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
//ok
GtkTreeIter iter;
gchar* type;
gint jour;
gint heure;
gint num;
gint val;
alarme al;
char type0[30];

GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&type,1,&num,2,&jour,3,&heure,4,&val,-1);
al.num=num;
al.jour=jour;
al.heure=heure;
al.val=val;
strcpy(type0,type);
supprimer_alarme(al,type0);
afficher_alarme(treeview);
}


}


void
on_button_alarme_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_liste;
GtkWidget *window_alarme;
GtkWidget *treeview;

window_liste=lookup_widget(objet,"liste_capteur");
gtk_widget_destroy(window_liste);

window_alarme=lookup_widget(objet,"alarme");
window_alarme =create_alarme ();

gtk_widget_show (window_alarme);

treeview=lookup_widget(window_alarme,"treeview21_alarme");
afficher_alarme(treeview);
}


void
on_button_alac_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
//ok
GtkWidget *window_alarme,*w1;
GtkWidget *treeview;



w1=lookup_widget(objet,"alarme");
window_alarme =create_alarme ();

gtk_widget_show (window_alarme);

gtk_widget_hide(w1);
treeview=lookup_widget(window_alarme,"treeview21_alarme");

vider_alarme(treeview);
afficher_alarme(treeview);
}


void
on_button_fumee_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
//ok
GtkWidget *window_alarme,*w1;
GtkWidget *treeview;



w1=lookup_widget(objet,"alarme");
window_alarme =create_alarme ();

gtk_widget_show (window_alarme);

gtk_widget_hide(w1);
treeview=lookup_widget(window_alarme,"treeview21_alarme");

vider_alarme(treeview);
afficher_fumee_alarme(treeview);
}


void
on_button_mouv_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
//ok
GtkWidget *window_alarme,*w1;
GtkWidget *treeview;



w1=lookup_widget(objet,"alarme");
window_alarme =create_alarme ();

gtk_widget_show (window_alarme);

gtk_widget_hide(w1);
treeview=lookup_widget(window_alarme,"treeview21_alarme");

vider_alarme(treeview);
afficher_mouv_alarme(treeview);
}


void
on_button_retoura_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_liste;
GtkWidget *window_alarme;

window_liste =create_liste_capteur ();
gtk_widget_show (window_liste);

window_alarme=lookup_widget(objet,"alarme");
gtk_widget_destroy(window_alarme);
}


void
on_treeview22_def_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* type;
gint jour;
gint heure;
gint num;
gfloat val;
temperature temp;

GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&type,1,&num,2,&jour,3,&heure,4,&val,-1);
temp.num=num;
temp.jour=jour;
temp.heure=heure;
temp.val=val;
supprimer_temperature(temp);
afficher_temperature(treeview);
}
}


void
on_button67_defec_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_liste;
GtkWidget *window_def;
GtkWidget *treeview;

window_liste=lookup_widget(objet,"liste_capteur");
gtk_widget_destroy(window_liste);

window_def=lookup_widget(objet,"defectueux");
window_def =create_defectueux ();

gtk_widget_show (window_def);

treeview=lookup_widget(window_def,"treeview22_def");
afficher_temperature(treeview);
}


void
on_button68_chercher_ref_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{

//ok
GtkWidget *ref_s;
GtkWidget *ref;
GtkWidget *type;
GtkWidget *achat;
GtkWidget *val;
GtkWidget *d_val;
GtkWidget *pos;
int test;
GtkWidget *msg;
ref_s=lookup_widget(objet,"entry9_ref");
ref=lookup_widget(objet,"entry10_ref");
type=lookup_widget(objet,"entry11_type");
achat=lookup_widget(objet,"entry12_date_achat");
val=lookup_widget(objet,"entry13_val");
d_val=lookup_widget(objet,"entry14_date_val");
pos=lookup_widget(objet,"entry15_pos");

msg=lookup_widget(objet,"label207_msg");
strcpy(cap.ref_cap,gtk_entry_get_text(GTK_ENTRY(ref_s)));
test=verifier_capteur(cap.ref_cap);
if (test==1)
{
gtk_label_set_text(GTK_LABEL(msg),"");
//remplir widgets
cap=recherche(cap.ref_cap);

gtk_entry_set_text(GTK_ENTRY(ref),cap.ref_cap);
gtk_entry_set_editable(GTK_ENTRY(ref),FALSE);

gtk_entry_set_text(GTK_ENTRY(type),cap.type);
gtk_entry_set_editable(GTK_ENTRY(type),FALSE);

char j_achat[50];
char m_achat[10];
char a_achat[10];
sprintf(j_achat,"%d",cap.date_achat.jour);
sprintf(m_achat,"%d",cap.date_achat.mois);
sprintf(a_achat,"%d",cap.date_achat.annee);
strcat(j_achat," / ");
strcat(j_achat,m_achat);
strcat(j_achat," / ");
strcat(j_achat,a_achat);
gtk_entry_set_text(GTK_ENTRY(achat),j_achat);
gtk_entry_set_editable(GTK_ENTRY(achat),FALSE);

char val_min[50];
char val_p[10];
char val_max[10];
sprintf(val_min,"%d",cap.val_min);
sprintf(val_p,"%f",cap.sh.val);
sprintf(val_max,"%d",cap.val_max);
strcat(val_min," ; ");
strcat(val_min,val_p);
strcat(val_min," ; ");
strcat(val_min,val_max);
gtk_entry_set_text(GTK_ENTRY(val),val_min);
gtk_entry_set_editable(GTK_ENTRY(val),FALSE);


char j_val[70];
char m_val[10];
char a_val[10];
char h_val[50];
char mm_val[10];
char s_val[10];
sprintf(j_val,"%d",cap.sh.date_prise.jour);
sprintf(m_val,"%d",cap.sh.date_prise.mois);
sprintf(a_val,"%d",cap.sh.date_prise.annee);
sprintf(h_val,"%d",cap.sh.heure_prise.hh);
sprintf(mm_val,"%d",cap.sh.heure_prise.mm);
sprintf(s_val,"%d",cap.sh.heure_prise.s);

strcat(j_val," / ");
strcat(j_val,m_val);
strcat(j_val," / ");
strcat(j_val,a_val);
strcat(j_val,"    ");

strcat(j_val,h_val);
strcat(j_val," : ");
strcat(j_val,mm_val);
strcat(j_val," : ");
strcat(j_val,s_val);
gtk_entry_set_text(GTK_ENTRY(d_val),j_val);
gtk_entry_set_editable(GTK_ENTRY(d_val),FALSE);

char etage[10];
char bloc[40];
sprintf(etage,"%d",cap.pos.etage);
strcpy(bloc,"Bloc ");
strcat(bloc,cap.pos.bloc);
strcat(bloc,"  ,etage : ");
strcat(bloc,etage);
gtk_entry_set_text(GTK_ENTRY(pos),bloc);
gtk_entry_set_editable(GTK_ENTRY(pos),FALSE);


}
else if(test==0)
{
gtk_entry_set_text(GTK_ENTRY(ref),"");
gtk_entry_set_text(GTK_ENTRY(type),"");
gtk_entry_set_text(GTK_ENTRY(achat),"");
gtk_entry_set_text(GTK_ENTRY(val),"");
gtk_entry_set_text(GTK_ENTRY(d_val),"");
gtk_entry_set_text(GTK_ENTRY(pos),"");
gtk_entry_set_editable(GTK_ENTRY(ref),FALSE);
gtk_entry_set_editable(GTK_ENTRY(type),FALSE);
gtk_entry_set_editable(GTK_ENTRY(achat),FALSE);
gtk_entry_set_editable(GTK_ENTRY(val),FALSE);
gtk_entry_set_editable(GTK_ENTRY(d_val),FALSE);
gtk_entry_set_editable(GTK_ENTRY(pos),FALSE);
gtk_label_set_text(GTK_LABEL(msg),"Ce capteur n'existe pas");

}
}


void
on_button69_cap_retour_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *window_liste;
GtkWidget *window_capteur;

window_liste =create_liste_capteur ();
gtk_widget_show (window_liste);

window_capteur=lookup_widget(objet,"capteur");
gtk_widget_destroy(window_capteur);
}


void
on_button70_retour_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_liste;
GtkWidget *window_def;

window_liste =create_liste_capteur ();
gtk_widget_show (window_liste);

window_def=lookup_widget(objet,"defectueux");
gtk_widget_destroy(window_def);
}






//GtkTreePath *path;

//gboolean
//on_treeview12_button_press_event       (GtkWidget       *treeview,
//                                        GdkEventButton  *event,
//                                        gpointer         userdata)
//{
//	
//
//      /* single click with the right mouse button? */
//    if (event->type == GDK_BUTTON_PRESS  &&  event->button == 3)
//    {
//      g_print ("Single right click on the tree view.\n");
//
//      /* optional: select row if no row is selected or only
//       *  one other row is selected (will only do something
//       *  if you set a tree selection mode as described later
//       *  in the tutorial) */
//      if (1)
//      {
//        GtkTreeSelection *selection;
//
//        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
//
//        /* Note: gtk_tree_selection_count_selected_rows() does not
//         *   exist in gtk+-2.0, only in gtk+ >= v2.2 ! */
//        if (gtk_tree_selection_count_selected_rows(selection)  <= 1)
//        {
//           //GtkTreePath *path;
//
//           /* Get tree path for row that was clicked */
//           if (gtk_tree_view_get_path_at_pos(GTK_TREE_VIEW(treeview),
//                                             (gint) event->x, 
//                                             (gint) event->y,
//                                             &path, NULL, NULL, NULL))
//           {
//             gtk_tree_selection_unselect_all(selection);
//             gtk_tree_selection_select_path(selection, path);
//             //gtk_tree_path_free(path);
//           }
//        }
//      } /* end of optional bit */
//g_print("123");
//      treeview_popup_menu(treeview, event, userdata,path);
//g_print("444");
//      return TRUE; /* we handled this */
//    }

//    return FALSE; /* we did not handle this */

//}


//gboolean
//on_treeview12_popup_menu               (GtkWidget       *treeview,
//                                        gpointer         userdata)
//{
//g_print("onpop");
//treeview_popup_menu(treeview, NULL, userdata,path);
//
//    return TRUE; /* we handled this */
//
//}








void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{test_check=1;}
else
{test_check=0;}
}

