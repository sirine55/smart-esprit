#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "Dali.h"


void
on_buttonrecA_clicked                  (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *rec ,*admin ,*treeview;

admin=lookup_widget(objet_graphique,"Welc");
rec=create_recA();
gtk_widget_show(rec);
gtk_widget_hide(admin);

treeview=lookup_widget(rec,"treeviewrecA");
afficherrec(treeview) ; 
}


void
on_buttonrecE_clicked                  (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *rec ,*emp ,*treeview;

emp=lookup_widget(objet_graphique,"Welc");
rec=create_recE();
gtk_widget_show(rec);
gtk_widget_hide(emp);

treeview=lookup_widget(rec,"treeviewrecE");
afficherrec(treeview) ; 
}


void
on_buttonrecC_clicked                  (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *rec ,*Client ;

Client=lookup_widget(objet_graphique,"Welc");
rec=create_recC();
gtk_widget_show(rec);
gtk_widget_hide(Client);

}


void
on_recretourA_clicked                  (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *rec ,*admin;

rec=lookup_widget(objet_graphique,"recA");
admin=create_Welc();
gtk_widget_show(admin);
gtk_widget_hide(rec);
}


void
on_SupprecA_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
GtkWidget *rec ,*ciin ,*rec1 ,*treeview ;

char cin[50] ; 

ciin=lookup_widget(objet_graphique,"CINrecA");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(ciin)));

supprimerrec(cin);

rec=lookup_widget(objet_graphique,"recA");
rec1=create_recA(); 
gtk_widget_show(rec1);
gtk_widget_hide(rec);

treeview=lookup_widget(rec1,"treeviewrecA");
afficherrec(treeview) ; 
}


void
on_TraiterrecA_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
GtkWidget *rec ,*ciin ,*rec1 ,*treeview ;

char cin[50] ; 

ciin=lookup_widget(objet_graphique,"CINrecA");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(ciin)));

modifieretat(cin);

rec=lookup_widget(objet_graphique,"recA");
rec1=create_recA(); 
gtk_widget_show(rec1);
gtk_widget_hide(rec);

treeview=lookup_widget(rec1,"treeviewrecA");
afficherrec(treeview) ; 
}


void
on_buttontraiterrecE_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
GtkWidget *rec ,*ciin ,*rec1 ,*treeview ;

char cin[50] ; 

ciin=lookup_widget(objet_graphique,"cinrecE");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(ciin)));

modifieretat(cin);

rec=lookup_widget(objet_graphique,"recE");
rec1=create_recE(); 
gtk_widget_show(rec1);
gtk_widget_hide(rec);

treeview=lookup_widget(rec1,"treeviewrecE");
afficherrec(treeview) ; 
}


void
on_buttonsupprecE_clicked              (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
GtkWidget *rec ,*ciin ,*rec1 ,*treeview ;

char cin[50] ; 

ciin=lookup_widget(objet_graphique,"cinrecE");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(ciin)));

supprimerrec(cin);

rec=lookup_widget(objet_graphique,"recE");
rec1=create_recE(); 
gtk_widget_show(rec1);
gtk_widget_hide(rec);

treeview=lookup_widget(rec1,"treeviewrecE");
afficherrec(treeview) ; 
}


void
on_buttonretourrecE_clicked            (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *rec ,*admin;

rec=lookup_widget(objet_graphique,"recE");
admin=create_Welc();
gtk_widget_show(admin);
gtk_widget_hide(rec);
}


void
on_buttonretourrecC_clicked            (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *rec ,*admin;

rec=lookup_widget(objet_graphique,"recC");
admin=create_Welc();
gtk_widget_show(admin);
gtk_widget_hide(rec);
}


void
on_buttonrecenv_clicked                (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *modif ,*gemp ,*ciin , *mess ,*type ,*jj ,*mm ,*yy ;

char cin[50]; 
char message1[3000]; 
char type1[50]; 
int j ; 
int m ; 
int y ; 

ciin=lookup_widget(objet_graphique,"entrynomrec");
mess=lookup_widget(objet_graphique,"entryrecmsg");
type=lookup_widget(objet_graphique,"comboboxentryrec");
jj=lookup_widget(objet_graphique,"spinbuttonrecjj");
mm=lookup_widget(objet_graphique,"spinbuttonrecmm");
yy=lookup_widget(objet_graphique,"spinbuttonrecyy");

strcpy(cin,gtk_entry_get_text(GTK_ENTRY(ciin)));
strcpy(message1,gtk_entry_get_text(GTK_ENTRY(mess)));
strcpy(type1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
y=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(yy));

reclamer(cin,message1,type1,j,m,y);

modif=lookup_widget(objet_graphique,"recC");
gemp=create_Welc();
gtk_widget_show(gemp);
gtk_widget_hide(modif);
}

