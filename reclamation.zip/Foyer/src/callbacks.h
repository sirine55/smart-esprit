#include <gtk/gtk.h>


void
on_buttonrecA_clicked                  (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonrecE_clicked                  (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonrecC_clicked                  (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_recretourA_clicked                  (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_SupprecA_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_TraiterrecA_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttontraiterrecE_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsupprecE_clicked              (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourrecE_clicked            (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourrecC_clicked            (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonrecenv_clicked                (GtkButton       *objet_graphique,
                                        gpointer         user_data);
