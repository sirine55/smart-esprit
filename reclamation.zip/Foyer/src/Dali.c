#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"Dali.h"
#include <gtk/gtk.h>

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

/*----------------------envoyerrec---------------------------------------------------------------------*/

void reclamer(char cin[] ,char message[] ,char type[],int j ,int m , int y ) 
{
FILE *f;

char etat[50]="NonTraitée" ;

f=fopen("/home/med/Foyer/src/reclamation.txt","a");
if(f!=NULL)
{fprintf(f,"%s %s %d/%d/%d %s %s \n",cin,type,j,m,y,etat,message);
fclose(f);
}
}


/*---------------------------afficherrec-------------------------------------------------*/


enum 
{
CIN1 , 
MESSAGE1 , 
TYPE1,
DATE1,
ETAT1,
COLUMNS111 
};
void afficherrec (GtkTreeView *liste) 
{
GtkCellRenderer *render ;
GtkTreeViewColumn *column ; 
GtkTreeIter iter ; 

GtkListStore *store ;

char cin[50]; 
char message[3000];
char type[50]; 
char date[50]; 
char etat[50]; 

 

store=NULL ; 
FILE* f ; 

store=gtk_tree_view_get_model(liste) ; 
if (store==NULL) 
{

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("cin",render,"text",CIN1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column=gtk_tree_view_column_new_with_attributes("message",render,"text",MESSAGE1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("type",render,"text",TYPE1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("date",render,"text",DATE1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("etat",render,"text",ETAT1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


store=gtk_list_store_new(COLUMNS111,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING) ; 

f=fopen("/home/med/Foyer/src/reclamation.txt","r") ;
if (f!=NULL)
{
f=fopen("/home/med/Foyer/src/reclamation.txt","a+") ;
 while(fscanf(f,"%s %s %s %s %[^\n]s \n",cin,type,date,etat,message)!=EOF) 
{
gtk_list_store_append (store,&iter) ; 
gtk_list_store_set (store,&iter,CIN1,cin,MESSAGE1,message,TYPE1,type,DATE1,date,ETAT1,etat,-1) ; 
}
fclose(f) ; }
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store)); 
g_object_unref (store) ; 
}
}

/*---------------------------------------------Modifieretat---------------------------------*/


void modifieretat(char cin1[])
{
FILE *f;
FILE *f1;
 
int r;
char etat1[50]="Traitée";
char cin[50]; 
char message[3000];
char type[50]; 
char date[50]; 
char etat[50]; 

f=fopen("/home/med/Foyer/src/reclamation.txt","r");
f1=fopen("/home/med/Foyer/src/reclamation1.txt","w");
if (f!=NULL)
{
    if(f1!=NULL)
     {
while(fscanf(f,"%s %s %s %s %[^\n]s \n",cin,type,date,etat,message)!=EOF ) 
{
    if(strcmp(cin1,cin)==0)  
            {
        fprintf(f1,"%s %s %s %s %s \n",cin,type,date,etat1,message);
            }
     else 
          {fprintf(f1,"%s %s %s %s %s \n",cin,type,date,etat,message);} 
}
}
}
fclose(f1);
fclose(f);

	remove ("/home/med/Foyer/src/reclamation.txt");
	rename ("/home/med/Foyer/src/reclamation1.txt","/home/med/Foyer/src/reclamation.txt");
	
}
/*---------------------------------------------Supprimerrec---------------------------------*/

void supprimerrec(char cin1[])

{
FILE *f;
FILE *f1;

int r;
int n;

char cin[50]; 
char message[3000];
char type[50]; 
char date[50]; 
char etat[50]; 


f=fopen("/home/med/Foyer/src/reclamation.txt","r");
f1=fopen("/home/med/Foyer/src/reclamation1.txt","w");
if (f!=NULL){
    if(f1!=NULL){
while(fscanf(f,"%s %s %s %s %[^\n]s \n",cin,type,date,etat,message)!=EOF ) {
    if(strcmp(cin1,cin)!=0)  
    {
        fprintf(f1,"%s %s %s %s %s \n",cin,type,date,etat,message);
        r=1;
    }
}
    }
    fclose(f1);
}

fclose(f);
if (r){
	remove ("/home/med/Foyer/src/reclamation.txt");
	rename ("/home/med/Foyer/src/reclamation1.txt","/home/med/Foyer/src/reclamation.txt");
	}

}



