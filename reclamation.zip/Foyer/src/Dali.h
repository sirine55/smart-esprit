#include <gtk/gtk.h>


void reclamer(char cin[] ,char message[] ,char type[],int j ,int m , int y ) ;
void afficherrec (GtkTreeView *liste);
void modifieretat(char cin1[]); 
void supprimerrec(char cin1[]);
