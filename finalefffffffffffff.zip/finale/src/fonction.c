
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonction.h"

#include <gtk/gtk.h> 

enum{
NOM,
DATE,
CATEGORIE,
ENTREE,
PLATPRINCIPAL,
DESSERT,
COLUMNS,
};
void ajouter_un_menu(menu M)
{
FILE *f;

f=fopen("menu.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %d/%s/%d %s %s%s %s/%s/%s %s %s\n",M.nom,M.da.jour,M.da.mois,M.da.annee,M.categorie,M.ent.salade,M.ent.soupe,M.pp.pate,M.pp.sauce,M.pp.viande,M.d.gateau,M.d.fruit );
}
fclose(f);
}
void afficher_un_menu(GtkWidget * liste){

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char nom [50];
char date [50];
char categorie [50];
char entree[50];
char plat_principal[50];
char dessert [50];
store=NULL;
menu M;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("categorie",renderer,"text",CATEGORIE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("entree",renderer,"text",ENTREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("plat_principal",renderer,"text",PLATPRINCIPAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("dessert",renderer,"text",DESSERT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("menu.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("menu.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s\n",nom,date,categorie,entree,plat_principal,dessert)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,DATE,date,CATEGORIE,categorie,ENTREE,entree,PLATPRINCIPAL,plat_principal,DESSERT,dessert,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

int exist_nom(char* nom){
FILE*f=NULL;
menu M;
f=fopen("menu.txt","r");
while(fscanf(f,"%s  \n",M.nom)!=EOF){
if(strcmp(M.nom,nom)==0)
return 1;    
}
fclose(f);
return 0;
}


void rechercher_un_menu(menu M)  
{
FILE* f;
FILE* f1;
char nom [50];
char date [50];
char categorie [50];
char entree[50];
char plat_principal[50];
char dessert [50];

f=fopen("menu.txt","r");
f1=fopen("menucher.txt","w");
  while(fscanf(f,"%s %s %s %s %s %s \n",nom,date,categorie,entree,plat_principal,dessert)!=EOF)
{
if (strcmp(M.nom,nom)==0)
{
fprintf(f1,"%s %s %s %s %s %s \n",nom,date,categorie,entree,plat_principal,dessert);
}
}
fclose(f);
fclose(f1);
}

void afficher_menu_chercher(GtkWidget *liste)
{
      GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

char nom [50];
char date [50];
char categorie [50];
char entree[50];
char plat_principal[50];
char dessert [50];

	store=NULL;
	
	FILE *f;
 
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("categorie",renderer,"text",CATEGORIE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("entree",renderer,"text",ENTREE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("plat_principal",renderer,"text",PLATPRINCIPAL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("dessert",renderer,"text",DESSERT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	}
		store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f = fopen("menucher.txt","r");
	if(f==NULL)
	{
	return;
	}
	else
	{
	 f=fopen("menucher.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s\n",nom,date,categorie,entree,plat_principal,dessert)!=EOF)
		{
		gtk_list_store_append(store,&iter);
		 gtk_list_store_set(store,&iter ,NOM,nom,DATE,date,CATEGORIE,categorie,ENTREE,entree,PLATPRINCIPAL,plat_principal,DESSERT,dessert,-1);		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);

	}
}
void modifier_un_menu(menu M)
{
FILE *f;
FILE *t;
menu n ;

f=fopen("menu.txt","r");
t=fopen("temp.text","a+");

    if (f!=NULL || t!=NULL)
    {
    while(fscanf(f,"%s %d/%s/%d %s %s%s %s/%s/%s %s %s \n",n.nom,&n.da.jour,n.da.mois,&n.da.annee,n.categorie,n.ent.salade,n.ent.soupe,n.pp.pate,n.pp.sauce,n.pp.viande,n.d.gateau,n.d.fruit)!=EOF)
    {
    if(strcmp(n.nom,M.nom)==0)
        {
fprintf(t,"%s %d/%s/%d %s %s%s %s/%s/%s %s %s \n",M.nom,M.da.jour,M.da.mois,M.da.annee,M.categorie,M.ent.salade,M.ent.soupe,M.pp.pate,M.pp.sauce,M.pp.viande,M.d.gateau,M.d.fruit);
}

    }
    }
fclose(t);
fclose(f);
remove("menu.txt");
rename("temp.text","menu.txt");
}


void supprimer_menu(char nom[])
{

char nom1[20],nom2[20];
char n1[20] , n2[20],n3[20],n4[20],n5[20];
char msg [50];
int trouve=0;
FILE *f,*E ;
f=fopen("menu.txt","r");
E=fopen("menutemp.txt","w");
  while (fscanf (f, "%s %s %s %s %s %s", &nom2,&n1,&n2,&n3,&n4,&n5) == 6)
    if (strcmp (nom2,nom) != 0)
{
      fprintf (E,"%s %s %s %s %s %s\n", nom2,n1,n2,n3,n4,n5);

}


  fclose(f);
  fclose(E);
f=fopen("menu.txt","w");
E=fopen("menutemp.txt","r");
  while (fscanf (E, "%s %s %s %s %s %s", &nom2,&n1,n2,&n3,&n4,&n5) == 6)
      fprintf (f,"%s %s %s %s %s %s\n", nom2,n1,n2,n3,n4,n5);
 fclose (f);
 fclose(E);

}
