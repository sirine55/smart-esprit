
#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#endif // FONCTION_H_INCLUDED
#include <gtk/gtk.h> 

typedef struct {
char salade [15];
 char soupe [20];
}entree;

typedef struct {
char pate[15];
char sauce [15];
char viande[30];
} plat_principal ;

typedef struct {
char fruit [15];
char gateau [20];
}dessert ;
typedef struct {
int jour;
char mois [20];
int annee;
}date;


typedef struct {
char nom[20];
date da;
char categorie[30];
plat_principal pp;
entree ent;
dessert d;


}menu ;
menu M;
int x;
int y;
int z;
int h;
int a;
int b;
int c;
int k;
void ajouter_un_menu(menu M);

void rechercher_un_menu(menu M);
void afficher_menu_chercher(GtkWidget *liste);

void afficher_un_menu(GtkWidget * liste);

void modifier_un_menu(menu M);
void supprimer_un_menu(char nom[20],menu M);
void supprimer_menu(char nom[]);
int exist_nom(char* nom);


