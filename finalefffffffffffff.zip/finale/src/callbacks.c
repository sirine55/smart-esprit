#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "dechet.h"

void
on_button_ajouter_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
menu M;
GtkWidget *input1,*input2,*input3,*input4,*input6,*input7,*input8,*input9,*success ;

success=lookup_widget(objet,"label_ajout_msg");

GdkColor color;
gdk_color_parse("red",&color);
gtk_widget_modify_fg(success,GTK_STATE_NORMAL,&color);

input1=lookup_widget (objet, "entry_nom_menu");

input2=lookup_widget (objet, "spinbutton_jour_ajout");
input3=lookup_widget (objet, "comboboxentry_mois");
input4=lookup_widget (objet, "spinbutton_annee_ajout");



input6=lookup_widget (objet, "entry_viande");

input7=lookup_widget (objet, "entry_nom_soupe_salade");

input8=lookup_widget (objet, "entry_nom_pate_sauce");

input9=lookup_widget (objet, "entry_nom_gateau_fruit");

strcpy(M.nom, gtk_entry_get_text(GTK_ENTRY(input1)));

M.da.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
strcpy(M.da.mois, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
M.da.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));



strcpy(M.pp.viande ,gtk_entry_get_text(GTK_ENTRY(input6)));

if (x==1)
{
strcpy(M.ent.salade, gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(M.ent.soupe,"");
}else if (x==2)
{
strcpy(M.ent.soupe, gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(M.ent.salade,"");
}

if (y==1)
{
strcpy(M.pp.pate, gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(M.pp.sauce,"");
}else if (y==2)
{
strcpy(M.pp.sauce, gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(M.pp.pate,"");
}

if (z==1)
{
strcpy(M.d.gateau, gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(M.d.fruit,"");
}else if (z==2)
{
strcpy(M.d.fruit, gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(M.d.gateau,"");
}

if(h==1)
{
strcpy(M.categorie, "dejeuner");
}
if(h==2)
{
strcpy(M.categorie, "dinner");
}

gtk_label_set_text(GTK_LABEL(success),"Ajout réuissite");
ajouter_un_menu(M);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *nom;
gchar *date;
gchar *categorie;
gchar *entree;
gchar *plat_principal;
gchar *dessert;

menu M;
 GtkTreeModel *model=gtk_tree_view_get_model(treeview1);
if (gtk_tree_model_get_iter(model,&iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&nom,1,&date,3,&categorie,4,&entree,5,&plat_principal,6,&dessert,-1);

supprimer_menu(nom);
afficher_un_menu(treeview1);
}
}

void
on_button_afficher_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_accueil;
GtkWidget *treeview1;

fenetre_accueil=lookup_widget(objet,"fenetre_accueil");

gtk_widget_show(fenetre_accueil);

treeview1=lookup_widget(fenetre_accueil,"treeview1");
afficher_un_menu(treeview1);
}


void
on_button_actualiser_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_accueil,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet,"fenetre_accueil");
fenetre_accueil=create_fenetre_accueil();

gtk_widget_show(fenetre_accueil);

gtk_widget_hide(w1);

treeview1=lookup_widget(fenetre_accueil,"treeview1");
afficher_un_menu(treeview1);

}


void
on_button_Rechercher_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
 menu M;
GtkWidget *input11;
GtkWidget *nonexiste;

input11=lookup_widget(objet,"entry_nom_supprimer");
nonexiste=lookup_widget(objet,"label_rechercher_msg");


strcpy(M.nom,gtk_entry_get_text(GTK_ENTRY(input11)));

if (exist_nom(M.nom)==0)
{ 
    gtk_label_set_text(GTK_LABEL(nonexiste),"menu non existant");
}
else 
{
    gtk_label_set_text(GTK_LABEL(nonexiste),"menu trouvée");
}

rechercher_un_menu(M);
 


gtk_entry_set_text(GTK_ENTRY(input11),"");
GtkWidget *treeview1;
treeview1=lookup_widget(objet,"treeview1");
afficher_menu_chercher(treeview1);
}


void
on_button_supprimer_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
GtkWidget *input55;
menu M;

char nom1[20],nom2[20];
char n1[20] , n2[20],n3[20],n4[20],n5[20];
char msg [50];
int trouve=0;
FILE *f,*E ;
input55=lookup_widget(objet,"label_supprimer_msg");
input1= lookup_widget (objet, "entry_nom_supprimer");
strcpy(nom1, gtk_entry_get_text(GTK_ENTRY(input1)));

f=fopen("menu.txt","r");
E=fopen("menutemp.txt","w");
  while (fscanf (f, "%s %s %s %s %s %s", &nom2,&n1,&n2,&n3,&n4,&n5) == 6)
    if (strcmp (nom2, nom1) != 0)
{gtk_label_set_text(GTK_LABEL(input55),"menu non existant");
      fprintf (E, "%s %s %s %s %s %s\n", nom2,n1,n2,n3,n4,n5);

}
else
gtk_label_set_text(GTK_LABEL(input55),"menu supprimer"); 

  fclose(f);
  fclose(E);
f=fopen("menu.txt","w");
E=fopen("menutemp.txt","r");
  while (fscanf (E, "%s %s %s %s %s %s", &nom2,&n1,n2, &n3,&n4,&n5) == 6)
      fprintf (f, "%s %s %s %s %s %s\n", nom2,n1,n2, n3,n4,n5);
 fclose (f);
 fclose(E);

}


void
on_checkbutton_salade_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=1;
}


void
on_checkbutton_soupe_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=2;
}


void
on_checkbutton_sauce_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=1;
}


void
on_checkbutton_pate_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=2;
}


void
on_checkbutton_gateau_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
z=1;
}


void
on_checkbutton_fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
z=2;
}


void
on_radiobutton_dinner_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
h=1;
}


void
on_radiobutton_dejeuner_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
h=2;
}


void
on_button_remplir_modifier_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_radiobutton_dejeuner_modifier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
k=1;
}


void
on_radiobutton_diner_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{k=2;

}


void
on_checkbutton_soupe_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{a=1;

}


void
on_checkbutton_salade_modifier_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{a=2;

}


void
on_checkbutton_pate_modifier_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{b=1;

}


void
on_checkbutton_sauce_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{b=2;

}


void
on_checkbutton_gateau_modifier_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{c=1;

}


void
on_checkbutton_fruit_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{c=2;

}


void
on_button_modifier_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{menu M;
GtkWidget *input1,*input2,*input3,*input4,*input6,*input7,*input8,*input9,*success ;

success=lookup_widget(objet,"label_message_modifier");

GdkColor color;
gdk_color_parse("red",&color);
gtk_widget_modify_fg(success,GTK_STATE_NORMAL,&color);

input1=lookup_widget (objet, "entry_nom_modifier");

input2=lookup_widget (objet, "spinbutton_jour_modifier");
input3=lookup_widget (objet, "comboboxentry_mois_modifier");
input4=lookup_widget (objet, "spinbutton_annee_modifier");



input6=lookup_widget (objet, "entry_viande_modifier");

input7=lookup_widget (objet, "entry_nom_entree_modifier");

input8=lookup_widget (objet, "entry_nom_pp_modifier");

input9=lookup_widget (objet, "entry_nom_dessert_modifier");

strcpy(M.nom, gtk_entry_get_text(GTK_ENTRY(input1)));


M.da.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
strcpy(M.da.mois, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
M.da.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));



strcpy(M.pp.viande,gtk_entry_get_text(GTK_ENTRY(input6)));


if (a==2)
{
strcpy(M.ent.salade, gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(M.ent.soupe,"");
}else if (a==1)
{
strcpy(M.ent.soupe, gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(M.ent.salade,"");
}

if (b==1)
{
strcpy(M.pp.pate, gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(M.pp.sauce,"");
}else if (b==2)
{
strcpy(M.pp.sauce, gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(M.pp.pate,"");
}

if (c==1)
{
strcpy(M.d.gateau, gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(M.d.fruit,"");
}else if (c==2)
{
strcpy(M.d.fruit, gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(M.d.gateau,"");
}

if(k==1)
{
strcpy(M.categorie, "dejeuner");
}
if(k==2)
{
strcpy(M.categorie, "dinner");
}

gtk_label_set_text(GTK_LABEL(success),"Ajout réuissite");

modifier_un_menu(M);

}


void
on_button_meilleure_menu_clicked       (GtkButton       *objet,
                                        gpointer         user_data)
{


GtkWidget *best_menu ;
GtkWidget *fenetre_accueil;


fenetre_accueil=lookup_widget(objet,"fenetre_accueil");
gtk_widget_destroy(fenetre_accueil);
fenetre_accueil=lookup_widget(objet,"fenetre_accueil");
best_menu=create_best_menu();
gtk_widget_show(best_menu);


}


void
on_treeview_meilleure_row_activated    (GtkTreeView     *treeview_meilleure,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *jour;
gchar *temps;
gchar *valeur;
dechet D;
 GtkTreeModel *model=gtk_tree_view_get_model(treeview_meilleure);
if (gtk_tree_model_get_iter(model,&iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&jour,1,&temps,3,&valeur,-1);

afficher_meilleure_menu(treeview_meilleure);
}
}


void
on_button_afficher_meilleure_clicked   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *best_menu;
GtkWidget *treeview_meilleure;
best_menu=lookup_widget(objet,"best_menu");
gtk_widget_show(best_menu);
treeview_meilleure=lookup_widget(best_menu,"treeview_meilleure");
afficher_meilleure_menu(treeview_meilleure);
//meilleur_menu_de_la_semaine_nutrition();
}

