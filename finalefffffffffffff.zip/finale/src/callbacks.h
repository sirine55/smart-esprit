#include <gtk/gtk.h>


void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Rechercher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton_salade_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_soupe_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sauce_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_pate_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_gateau_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_dinner_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_dejeuner_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_remplir_modifier_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_dejeuner_modifier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_diner_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_soupe_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_salade_modifier_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_pate_modifier_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sauce_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_gateau_modifier_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_fruit_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_meilleure_menu_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_meilleure_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_afficher_meilleure_clicked   (GtkButton       *button,
                                        gpointer         user_data);
