#include <gtk/gtk.h>

enum 
{
	SEXE,
	CIN,
	NOM,
	PRENOM,
	CLASSE,
	DDJ,
	DDM,
	DDA,
	DEJ,
	DEM,
	DEA,
	DSJ,
	DSM,
	DSA,
	BLOC,
	ETAGE,
	NUM,
	PAIE,
	COLUMNS
};


typedef struct
{
    int j;
    int m;
    int a;
}date ;


typedef struct
{
    char bloc[10] ;
    int  num ;
    int etage;
}reff;


typedef struct
{
    char sexe[50];
    char classe [50] ;
    char cin[50];
    char nom[20];
    char prenom [20];
    date date_de_naissance ;
    date date_entree;
    date date_sortie;
    reff ref_ch;
    char paiement[50];
}etudiant ;



void ajouter_etudiant(etudiant e);
void chercher_etudiant(GtkWidget *liste, char cd[50]);
void afficher_etudiant(GtkWidget *liste);
void vider(GtkWidget *liste);
int exist(char cin[50], etudiant e);
int afficher1ere(GtkWidget *liste);
int afficher2eme(GtkWidget *liste);
int afficher3eme(GtkWidget *liste);
int afficher4eme(GtkWidget *liste);

