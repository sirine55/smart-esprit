#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "etudiant.h"

etudiant e;
int x;
int y;
int a;
int b;

void
on_chajouter_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *sexe;
GtkWidget *cin;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *classe;
GtkWidget *jd;
GtkWidget *md;
GtkWidget *ad;
GtkWidget *je;
GtkWidget *me;
GtkWidget *ae;
GtkWidget *js;
GtkWidget *ms;
GtkWidget *as;
GtkWidget *bloc;
GtkWidget *etage;
GtkWidget *chambre;
GtkWidget *paye;
GtkWidget *npaye;
GtkWidget *tranchea;
GtkWidget *trancheb;
GtkWidget *messg;
char test[20];
char r[30];


cin=lookup_widget(objet_graphique,"chentry_CIN");
nom=lookup_widget(objet_graphique,"chentry_nom");
prenom=lookup_widget(objet_graphique,"chentry_prenom");
classe=lookup_widget(objet_graphique,"chentry_classe");
jd=lookup_widget(objet_graphique,"chjour");
md=lookup_widget(objet_graphique,"chmois");
ad=lookup_widget(objet_graphique,"channee");
je=lookup_widget(objet_graphique,"chjour_entree");
me=lookup_widget(objet_graphique,"chmois_entree");
ae=lookup_widget(objet_graphique,"channee_entree");
js=lookup_widget(objet_graphique,"chjour_sortie");
ms=lookup_widget(objet_graphique,"chmois_sortie");
as=lookup_widget(objet_graphique,"channee_sortie");
bloc=lookup_widget(objet_graphique,"chcombobox1");
etage=lookup_widget(objet_graphique,"chetage");
chambre=lookup_widget(objet_graphique,"chspinbutton13");
sexe=lookup_widget(objet_graphique,"chcombobox6");
paye=lookup_widget(objet_graphique,"chpaye");
npaye=lookup_widget(objet_graphique,"chnonpaye");
tranchea=lookup_widget(objet_graphique,"chcheckbutton2");
trancheb=lookup_widget(objet_graphique,"chcheckbutton1");
messg=lookup_widget(objet_graphique,"chlabel60");


strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.classe,gtk_entry_get_text(GTK_ENTRY(classe)));

e.date_de_naissance.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jd));
e.date_de_naissance.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(md));
e.date_de_naissance.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ad));

e.date_entree.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(je));
e.date_entree.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(me));
e.date_entree.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ae));

e.date_sortie.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(js));
e.date_sortie.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
e.date_sortie.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(as));

e.ref_ch.etage=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etage));
e.ref_ch.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(chambre));

// les valeurs des combobox

strcpy(e.ref_ch.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(bloc)));
strcpy(e.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(sexe)));

 //remplir le fichier liste etudiant
if (x==1)
	{ if (y==1)
           strcpy(r,"1ère_tranche_payee");
	else if (y==2)
	   strcpy(r,"Paiement_totale");
        }
else if (x==2)
	{strcpy(r,"Non_payee");}

strcpy(e.paiement,r);

strcpy(test,e.cin);
if(exist(test,e)==1)
{
	gtk_label_set_text(GTK_LABEL(messg),"L'etudiant deja exist");
	gtk_widget_show(messg);
}
else
{
	ajouter_etudiant(e);
	gtk_label_set_text(GTK_LABEL(messg),"L'etudiant est bien ajouter!");
	gtk_widget_show(messg);
}
}


void
on_channulera_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
       GtkWidget *window1 , *window2;
	window1=create_chmenu();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chajoutere");
	gtk_widget_destroy (window2);
}


void
on_chpaye_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{
		x=1;
	}
}


void
on_chcheckbutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
	{
		y=1;
	}
}


void
on_chcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
	{
		y=2;
	}
}


void
on_chnonpaye_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{
		x=2;
	}
}


void
on_chretoura_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
		GtkWidget *window1 , *window2;
		window1=create_chmenu();
		gtk_widget_show (window1);
		window2=lookup_widget(objet_graphique,"chajoutere");
		gtk_widget_destroy (window2);
}


void
on_chtreeview7_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* cin[20];
	gchar* sexe[50];
	char cd[20];
	etudiant e;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	GtkWidget *pInfo;
	if(gtk_tree_model_get_iter(model,&iter,path))
	{	
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&sexe,1,&cin,-1);
	strcpy(cd,*cin);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce etudiant?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_etudiant(e,cd);
	//vider(treeview);
	afficher_etudiant(treeview);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}


void
on_chchercheret_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1=create_chchercher();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chmenu");
	gtk_widget_destroy (window2);
}


void
on_chajouteret_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2;
	window1=create_chajoutere();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chmenu");
	gtk_widget_destroy (window2);
}


void
on_chmodifieret_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2;
	window1=create_chmodifier();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chmenu");
	gtk_widget_destroy (window2);
}


void
on_chsupprimeret_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2;
	window1=create_chsupprimer();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chmenu");
	gtk_widget_destroy (window2);
}


void
on_chlisteetud_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
		GtkWidget *window1 , *window2;
		window1=create_chlistec();
		gtk_widget_show (window1);
		window2=lookup_widget(objet,"chmenu");
		gtk_widget_destroy (window2);
}


void
on_chretourmenu_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_chactualiserm_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1, *w1;
	GtkWidget *treeview7;

	w1=lookup_widget(objet_graphique,"chmenu");
	window1=create_chmenu();
	
	gtk_widget_show(window1);

	gtk_widget_hide (w1);
	treeview7=lookup_widget(window1,"chtreeview7");

	vider(treeview7);
	afficher_etudiant(treeview7);
}


void
on_channulers_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2;
	window1=create_chmenu();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chsupprimer");
	gtk_widget_destroy (window2);
}


void
on_chvaliders_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 	GtkWidget *cin;
	GtkWidget *messg;
	char cd[50];
	etudiant e;
	cin=lookup_widget(objet_graphique,"chentry_CINs");
	messg=lookup_widget(objet_graphique,"chlabel65");
	strcpy(cd,gtk_entry_get_text(GTK_ENTRY(cin)));
	if (exist(cd,e)==1)
	  {
		supprimer_etudiant(e,cd);
		gtk_label_set_text(GTK_LABEL(messg),"L'étudiant est supprimé avec succés !");
		gtk_widget_show(messg);
	  }
	else
	  {
		
	        gtk_label_set_text(GTK_LABEL(messg),"Aucun étudiant avec ce cin");
		gtk_widget_show(messg);

	  }

}


void
on_chafficherm_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	char cd[50];
	etudiant e;

	GtkWidget *cin;
	GtkWidget *nom;
	GtkWidget *prenom;
	GtkWidget *classe;
	GtkWidget *jd;
	GtkWidget *md;
	GtkWidget *ad;
	GtkWidget *je;
	GtkWidget *me;
	GtkWidget *ae;
	GtkWidget *js;
	GtkWidget *ms;
	GtkWidget *as;
	GtkWidget *bloc;
	GtkWidget *etage;
	GtkWidget *chambre;
	GtkWidget *paye;
	GtkWidget *npaye;
	GtkWidget *tranchea;
	GtkWidget *trancheb;
	GtkWidget *sexe;
	GtkWidget *messg;


cin=lookup_widget(objet_graphique,"chentry_cinm");
nom=lookup_widget(objet_graphique,"chentry_nomm");
prenom=lookup_widget(objet_graphique,"chentry_prenomm");
classe=lookup_widget(objet_graphique,"chentry_classem");
jd=lookup_widget(objet_graphique,"chjourm");
md=lookup_widget(objet_graphique,"chmoism");
ad=lookup_widget(objet_graphique,"chspinbutton17");
je=lookup_widget(objet_graphique,"chJour_em");
me=lookup_widget(objet_graphique,"chmois_em");
ae=lookup_widget(objet_graphique,"channee_em");
js=lookup_widget(objet_graphique,"chjour_sm");
ms=lookup_widget(objet_graphique,"chmois_sm");
as=lookup_widget(objet_graphique,"chspinbutton6");
bloc=me=lookup_widget(objet_graphique,"chentry6");
etage=lookup_widget(objet_graphique,"chspinbutton18");
chambre=lookup_widget(objet_graphique,"chspinbutton14");
paye=lookup_widget(objet_graphique,"chpayem");
npaye=lookup_widget(objet_graphique,"chnonpayem");
tranchea=lookup_widget(objet_graphique,"chcheckbutton3");
trancheb=lookup_widget(objet_graphique,"chcheckbutton4");
sexe=lookup_widget(objet_graphique,"chentry7");
messg=lookup_widget(objet_graphique,"chlabel98");
FILE *f;
strcpy(cd,gtk_entry_get_text(GTK_ENTRY(cin)));

if(exist(cd,e)==1)
{
	modifier_etudiant(e,cd);
	f=fopen("tmpo.txt","r");
	while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF)
		{
			gtk_entry_set_text(GTK_ENTRY(nom),e.nom);
			gtk_entry_set_text(GTK_ENTRY(prenom),e.prenom);
			gtk_entry_set_text(GTK_ENTRY(classe),e.classe);
			gtk_entry_set_text(GTK_ENTRY(sexe),e.sexe);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(jd),e.date_de_naissance.j);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(md),e.date_de_naissance.m);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(ad),e.date_de_naissance.a);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(je),e.date_entree.j);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(me),e.date_entree.m);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(ae),e.date_entree.a);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(js),e.date_sortie.j);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(ms),e.date_sortie.m);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(as),e.date_sortie.a);
			gtk_entry_set_text(GTK_ENTRY(bloc),e.ref_ch.bloc);
			{if (strcmp(e.paiement,"Paiement_totale")==0)
			{	
				gtk_toggle_button_set_active(paye,1);
				gtk_toggle_button_set_active(trancheb,1);
			}
			else if (strcmp(e.paiement,"1ère_tranche_payee")==0)
			{
				gtk_toggle_button_set_active(paye,1);
				gtk_toggle_button_set_active(tranchea,1);
			}
			else if (strcmp(e.paiement,"Non_payee")==0)
			{
				gtk_toggle_button_set_active(npaye,1);
				gtk_toggle_button_set_active(paye,0);
				gtk_toggle_button_set_active(trancheb,0);
				gtk_toggle_button_set_active(tranchea,0);
			}}
				


			gtk_label_set_text(GTK_LABEL(messg),"Voiçi les informations correspondantes à ce CIN");
			gtk_widget_show(messg);
		}
}
else 
{
	gtk_label_set_text(GTK_LABEL(messg),"Aucun étudiant avec ce num de CIN");
	gtk_widget_show(messg);
}
remove("tmpo.txt");
}


void
on_chpayem_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
	{
		a=1;
	}
}


void
on_chnonpayem_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
	{
		a=2;
	}
}


void
on_chcheckbutton3_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{
		b=1;
	}
}


void
on_chcheckbutton4_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{
		b=2;
	}
}


void
on_chvaliderm_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e;

GtkWidget *cin;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *classe;
GtkWidget *jd;
GtkWidget *md;
GtkWidget *ad;
GtkWidget *je;
GtkWidget *me;
GtkWidget *ae;
GtkWidget *js;
GtkWidget *ms;
GtkWidget *as;
GtkWidget *bloc;
GtkWidget *etage;
GtkWidget *chambre;
GtkWidget *paye;
GtkWidget *npaye;
GtkWidget *sexe;
GtkWidget *tranchea;
GtkWidget *trancheb;
GtkWidget *messg;
GtkWidget *msg;
char test[20];
char r[30];


cin=lookup_widget(objet_graphique,"chentry_cinm");
nom=lookup_widget(objet_graphique,"chentry_nomm");
prenom=lookup_widget(objet_graphique,"chentry_prenomm");
classe=lookup_widget(objet_graphique,"chentry_classem");
jd=lookup_widget(objet_graphique,"chjourm");
md=lookup_widget(objet_graphique,"chmoism");
ad=lookup_widget(objet_graphique,"chspinbutton17");
je=lookup_widget(objet_graphique,"chjour_em");
me=lookup_widget(objet_graphique,"chmois_em");
ae=lookup_widget(objet_graphique,"channee_em");
js=lookup_widget(objet_graphique,"chjour_sm");
ms=lookup_widget(objet_graphique,"chmois_sm");
as=lookup_widget(objet_graphique,"chspinbutton6");
bloc=lookup_widget(objet_graphique,"chcombobox5");
etage=lookup_widget(objet_graphique,"chspinbutton18");
chambre=lookup_widget(objet_graphique,"chspinbutton14");
paye=lookup_widget(objet_graphique,"chpayem");
npaye=lookup_widget(objet_graphique,"chnonpayem");
tranchea=lookup_widget(objet_graphique,"chcheckbutton3");
trancheb=lookup_widget(objet_graphique,"chcheckbutton4");
messg=lookup_widget(objet_graphique,"chlabel98");
msg=lookup_widget(objet_graphique,"chlabel99");
sexe=lookup_widget(objet_graphique,"chentry7");

strcpy(test,gtk_entry_get_text(GTK_ENTRY(cin)));
supprimer_etudiant(e,test);

strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.classe,gtk_entry_get_text(GTK_ENTRY(classe)));
strcpy(e.sexe,gtk_entry_get_text(GTK_ENTRY(sexe)));

e.date_de_naissance.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jd));
e.date_de_naissance.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(md));
e.date_de_naissance.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ad));

e.date_entree.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(je));
e.date_entree.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(me));
e.date_entree.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ae));

e.date_sortie.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(js));
e.date_sortie.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
e.date_sortie.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(as));

e.ref_ch.etage=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etage));
e.ref_ch.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(chambre));

// les valeurs des combobox

strcpy(e.ref_ch.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(bloc)));


 //remplir le fichier liste etudiant
if (a==1)
	{ 
	if (b==1)
           strcpy(r,"1ère_tranche_payee");
	else if (b==2)
	   strcpy(r,"Paiement_totale");
        }
else if (a==2)
	{strcpy(r,"Non_payee");}

strcpy(e.paiement,r);

ajouter_etudiant(e);
gtk_label_set_text(GTK_LABEL(msg),"les informations de l'etudiant sont mettres à jour");
gtk_widget_show(msg);
gtk_widget_hide(messg);
}


void
on_channulerm_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2;
	window1=create_chmenu();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chmodifier");
	gtk_widget_destroy (window2);
}


void
on_chbutton2_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2;
	window1=create_chmenu();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chmodifier");
	gtk_widget_destroy (window2);
}


void
on_chtreeview2_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	etudiant e;
	gchar *sexe;
	gchar *cin;
	gchar *nom;
	gchar *prenom;
	gchar *classe;
	gint jd;
	gint md;
	gint ad;
	gint je;
	gint me;
	gint ae;
	gint js;
	gint ms;
	gint as;
	gchar *bloc;
	gint  etage;
	gint num;
	gchar *p;

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&sexe,1,&cin,2,&nom,3,&prenom,4,&classe,5,&jd,6,&md,7,&ad,8,&je,9,&me,10,&ae,11,&js,12,&ms,13,&as,14,&bloc,15,&num,16,&etage,17,&p,-1);

	strcpy(e.sexe,sexe);
	strcpy(e.cin,cin);
	strcpy(e.nom,nom);
	strcpy(e.prenom,prenom);
	strcpy(e.classe,classe);
	e.date_de_naissance.j=jd;
	e.date_de_naissance.m=md;
	e.date_de_naissance.a=ad;
	e.date_de_naissance.j=je;
	e.date_de_naissance.m=me;
	e.date_de_naissance.a=ae;
	e.date_de_naissance.j=js;
	e.date_de_naissance.m=ms;
	e.date_de_naissance.a=as;
	strcpy(e.ref_ch.bloc,bloc);
	e.ref_ch.num=num;
	e.ref_ch.etage=etage;
	strcpy(e.paiement,p);
	chercher_etudiant(treeview,cin);
}
}


void
on_chchercherch_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *chercher;
	GtkWidget *messg;
	GtkWidget *treeview2;
	char cd[50];
	etudiant e;
	chercher=lookup_widget(objet_graphique,"chentry1");
	strcpy(cd,gtk_entry_get_text(GTK_ENTRY(chercher)));
	messg=lookup_widget(objet_graphique,"chlabel72");
	treeview2=lookup_widget(objet_graphique,"chtreeview2");
 	if (exist(cd,e)==1)
	{
		chercher_etudiant(treeview2,cd);
		gtk_label_set_text(GTK_LABEL(messg),"Voiçi l'étudiant qui correspond ce cin !");
		gtk_widget_show(messg);
	}
	else
	{
		gtk_label_set_text(GTK_LABEL(messg),"Aucun étudiant avec ce cin !");
		gtk_widget_show(messg);
	}
}


void
on_chactualiserch_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *cherch, *w1;
	GtkWidget *treeview2;
	GtkWidget *chercher;
	char cd[50];
	chercher=lookup_widget(objet_graphique,"chentry1");
	strcpy(cd,gtk_entry_get_text(GTK_ENTRY(chercher)));
	w1=lookup_widget(objet_graphique,"chchercher");
	cherch=create_chchercher();
	gtk_widget_show(cherch);
	gtk_widget_hide(w1);
	treeview2=lookup_widget(objet_graphique,"chtreeview2");
	vider(treeview2);
	chercher_etudiant(treeview2,cd);
}


void
on_chretourch_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2;
	window1=create_chmenu();
	gtk_widget_show (window1);
	window2=lookup_widget(objet_graphique,"chchercher");
	gtk_widget_destroy (window2);
}


void
on_chtreeview14_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_chtreeview12_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_chtreeview11_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_chtreeview13_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_chafficher1_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview11;
	int s;
	char nb[30];
	GtkWidget *entry12;
	entry12=lookup_widget(objet,"chentry12");
	treeview11=lookup_widget(objet,"chtreeview11");
	s=afficher1ere(treeview11);
	sprintf(nb,"%d",s);
	gtk_entry_set_text(GTK_ENTRY(entry12),nb);
}


void
on_chafficher2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview12;
	int n;
	char nb[30];
	GtkWidget *entry13;
	entry13=lookup_widget(objet,"chentry13");
	treeview12=lookup_widget(objet,"chtreeview12");
	n=afficher2eme(treeview12);
	sprintf(nb,"%d",n);
	gtk_entry_set_text(GTK_ENTRY(entry13),nb);
}


void
on_chafficher3_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview13;
	int k;
	char nb[30];
	GtkWidget *entry14;
    	entry14=lookup_widget(objet,"chentry14");
	treeview13=lookup_widget(objet,"chtreeview13");
	k=afficher3eme(treeview13);
	sprintf(nb,"%d",k);
	gtk_entry_set_text(GTK_ENTRY(entry14),nb);
}


void
on_chafficher4_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview14;
	int x;
	char nb[30];
	GtkWidget *entry15;
	entry15=lookup_widget(objet,"chentry15");
	treeview14=lookup_widget(objet,"chtreeview14");
	x=afficher4eme(treeview14);
	sprintf(nb,"%d",x);
	gtk_entry_set_text(GTK_ENTRY(entry15),nb);
}


void
on_chretourlist_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2;
	window1=create_chmenu();
	gtk_widget_show (window1);
	window2=lookup_widget(objet,"chlistec");
	gtk_widget_destroy (window2);
}

