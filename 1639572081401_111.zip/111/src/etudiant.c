#include "etudiant.h"
#include "callbacks.h"
#include "interface.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
int exist(char cin[50], etudiant e)
{	
	FILE *f;
	f=fopen("etudiant.txt","r");
	while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF)
{
	if(strcmp(cin,e.cin)==0)
		return 1;
}
fclose(f);
return 0;
}

void ajouter_etudiant(etudiant e)
{ 
    FILE *f;
    
    f=fopen("etudiant.txt","a+");
	if (f!=NULL)
{
    fprintf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,e.date_de_naissance.j,e.date_de_naissance.m,e.date_de_naissance.a,e.date_entree.j,e.date_entree.m,e.date_entree.a,e.date_sortie.j,e.date_sortie.m,e.date_sortie.a,e.ref_ch.bloc,e.ref_ch.num,e.ref_ch.etage,e.paiement);
    fclose(f);
}
}

void modifier_etudiant(etudiant e , char cd[50])
{
FILE* f;
FILE* tmpo;


tmpo=fopen("tmpo.txt","w");
f=fopen("etudiant.txt","r");


while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF)
    {
	if (strcmp(cd,e.cin)==0)
	{
		fprintf(tmpo,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,e.date_de_naissance.j,e.date_de_naissance.m,e.date_de_naissance.a,e.date_entree.j,e.date_entree.m,e.date_entree.a,e.date_sortie.j,e.date_sortie.m,e.date_sortie.a,e.ref_ch.bloc,e.ref_ch.num,e.ref_ch.etage,e.paiement);
       	}
    }
    fclose(f);
    fclose(tmpo);
}


void supprimer_etudiant(etudiant e, char cd[9])
{ 
    
    FILE *f;
    FILE *tmp;
    f=fopen("etudiant.txt","r");
    tmp=fopen("tmp.txt","w");

       while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF)
       {
        if (strcmp(cd,e.cin)!=0)
fprintf(tmp,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,e.date_de_naissance.j,e.date_de_naissance.m,e.date_de_naissance.a,e.date_entree.j,e.date_entree.m,e.date_entree.a,e.date_sortie.j,e.date_sortie.m,e.date_sortie.a,e.ref_ch.bloc,e.ref_ch.num,e.ref_ch.etage,e.paiement);
       }
        fclose(f);
        fclose(tmp);
        remove("etudiant.txt");
        rename("tmp.txt","etudiant.txt");

} 

void chercher_etudiant(GtkWidget *liste,char cd[])
{
GtkCellRenderer *renderer;  //envoyer la saisie de l'utilisateur de chaque champs
GtkTreeViewColumn *column;  //correspondre le contenue de champ a son variable de la liste
GtkTreeIter iter;
GtkListStore *store;

    char Sexe [30];
    char Cin [9];
    char Nom [30];
    char Prenom[30];
    char Classe[30];
    int j_Naiss;
    int m_Naiss;
    int a_Naiss;
    int j_E;
    int m_E;
    int a_E;
    int j_S;
    int m_S;
    int a_S;
    char Bloc[30];
    int Etage;
    int Num_chambre ;
    char Paiement[30];
   
    etudiant e;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Sexe", renderer, "text",SEXE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Cin", renderer, "text",CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new(); 
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Classe", renderer, "text",CLASSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_Naiss", renderer, "text",DDJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_Naiss", renderer, "text",DDM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_Naiss", renderer, "text",DDA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_E", renderer, "text",DEJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_E", renderer, "text",DEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_E", renderer, "text",DEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_S", renderer, "text",DSJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_S", renderer, "text",DSM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_S", renderer, "text",DSA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Bloc", renderer, "text",BLOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num_chambre", renderer, "text",NUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Etage", renderer, "text",ETAGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Paiement", renderer, "text",PAIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);

f=fopen("etudiant.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("etudiant.txt","a+");
while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF)
{
if(strcmp(e.cin,cd)==0)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter, SEXE, e.sexe, CIN, e.cin, NOM, e.nom, PRENOM, e.prenom, CLASSE, e.classe, DDJ, e.date_de_naissance.j, DDM, e.date_de_naissance.m, DDA, e.date_de_naissance.a, DEJ, e.date_entree.j, DEM, e.date_entree.m, DEA, e.date_entree.a, DSJ, e.date_sortie.j, DSM, e.date_sortie.m, DSA, e.date_sortie.a, BLOC, e.ref_ch.bloc, NUM, e.ref_ch.num, ETAGE, e.ref_ch.etage, PAIE, e.paiement,-1);
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref (store);
}
}



void afficher_etudiant(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

    char Sexe [30];
    char Cin [9];
    char Nom [30];
    char Prenom[30];
    char Classe[30];
    int j_Naiss;
    int m_Naiss;
    int a_Naiss;
    int j_E;
    int m_E;
    int a_E;
    int j_S;
    int m_S;
    int a_S;
    char Bloc[30];
    int Etage;
    int Num_chambre ;
    char Paiement[30];
   
    etudiant e;

    FILE *f;
    
   store=gtk_tree_view_get_model(liste);
   if (store==NULL)
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Sexe", renderer, "text",SEXE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Cin", renderer, "text",CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new(); 
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Classe", renderer, "text",CLASSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_Naiss", renderer, "text",DDJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_Naiss", renderer, "text",DDM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_Naiss", renderer, "text",DDA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_E", renderer, "text",DEJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_E", renderer, "text",DEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_E", renderer, "text",DEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_S", renderer, "text",DSJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_S", renderer, "text",DSM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_S", renderer, "text",DSA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Bloc", renderer, "text",BLOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num_chambre", renderer, "text",NUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Etage", renderer, "text",ETAGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Paiement", renderer, "text",PAIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
     store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);

    f=fopen("etudiant.txt","r");

if(f==NULL)
{
return;
}
else 
{
f=fopen("etudiant.txt","a+");
while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF){  
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store, &iter, SEXE, e.sexe, CIN, e.cin, NOM, e.nom, PRENOM, e.prenom, CLASSE, e.classe, DDJ, e.date_de_naissance.j, DDM, e.date_de_naissance.m, DDA, e.date_de_naissance.a, DEJ, e.date_entree.j, DEM, e.date_entree.m, DEA, e.date_entree.a, DSJ, e.date_sortie.j, DSM, e.date_sortie.m, DSA, e.date_sortie.a, BLOC, e.ref_ch.bloc, NUM, e.ref_ch.num, ETAGE, e.ref_ch.etage, PAIE, e.paiement,-1);
}
   fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

void vider(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

    char Sexe [30];
    char Cin [9];
    char Nom [30];
    char Prenom[30];
    char Classe[30];
    int j_Naiss;
    int m_Naiss;
    int a_Naiss;
    int j_E;
    int m_E;
    int a_E;
    int j_S;
    int m_S;
    int a_S;
    char Bloc[30];
    int Etage;
    int Num_chambre ;
    char Paiement[30];

    FILE *f;
    
   store=gtk_tree_view_get_model(liste);
   if (store==NULL)
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Sexe", renderer, "text",SEXE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Cin", renderer, "text",CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new(); 
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Classe", renderer, "text",CLASSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_Naiss", renderer, "text",DDJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_Naiss", renderer, "text",DDM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_Naiss", renderer, "text",DDA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_E", renderer, "text",DEJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_E", renderer, "text",DEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_E", renderer, "text",DEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_S", renderer, "text",DSJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_S", renderer, "text",DSM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_S", renderer, "text",DSA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Bloc", renderer, "text",BLOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num_chambre", renderer, "text",NUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Etage", renderer, "text",ETAGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Paiement", renderer, "text",PAIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
       store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);
gtk_list_store_append(store, &iter);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
}
/////////////////////////////////////////////////
int afficher1ere(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

	int s=0;

    char Sexe [30];
    char Cin [9];
    char Nom [30];
    char Prenom[30];
    char Classe[30];
    int j_Naiss;
    int m_Naiss;
    int a_Naiss;
    int j_E;
    int m_E;
    int a_E;
    int j_S;
    int m_S;
    int a_S;
    char Bloc[30];
    int Etage;
    int Num_chambre ;
    char Paiement[30];
   
    etudiant e;


    FILE *f;
    
   store=gtk_tree_view_get_model(liste);
   if (store==NULL)
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Sexe", renderer, "text",SEXE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Cin", renderer, "text",CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new(); 
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Classe", renderer, "text",CLASSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_Naiss", renderer, "text",DDJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_Naiss", renderer, "text",DDM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_Naiss", renderer, "text",DDA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_E", renderer, "text",DEJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_E", renderer, "text",DEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_E", renderer, "text",DEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_S", renderer, "text",DSJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_S", renderer, "text",DSM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_S", renderer, "text",DSA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Bloc", renderer, "text",BLOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num_chambre", renderer, "text",NUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Etage", renderer, "text",ETAGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Paiement", renderer, "text",PAIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
     store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);

    f=fopen("etudiant.txt","r");

if(f==NULL)
{
return;
}
else 
{
f=fopen("etudiant.txt","a+");
while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF){  
	if(e.ref_ch.etage==1)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store, &iter, SEXE, e.sexe, CIN, e.cin, NOM, e.nom, PRENOM, e.prenom, CLASSE, e.classe, DDJ, e.date_de_naissance.j, DDM, e.date_de_naissance.m, DDA, e.date_de_naissance.a, DEJ, e.date_entree.j, DEM, e.date_entree.m, DEA, e.date_entree.a, DSJ, e.date_sortie.j, DSM, e.date_sortie.m, DSA, e.date_sortie.a, BLOC, e.ref_ch.bloc, NUM, e.ref_ch.num, ETAGE, e.ref_ch.etage, PAIE, e.paiement,-1);
	s++;
	}
}
   fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
return s;
}

///////////////////////////////////////////////
int afficher2eme(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

	int n=0;

    char Sexe [30];
    char Cin [9];
    char Nom [30];
    char Prenom[30];
    char Classe[30];
    int j_Naiss;
    int m_Naiss;
    int a_Naiss;
    int j_E;
    int m_E;
    int a_E;
    int j_S;
    int m_S;
    int a_S;
    char Bloc[30];
    int Etage;
    int Num_chambre ;
    char Paiement[30];
   
    etudiant e;


    FILE *f;
    
   store=gtk_tree_view_get_model(liste);
   if (store==NULL)
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Sexe", renderer, "text",SEXE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Cin", renderer, "text",CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new(); 
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Classe", renderer, "text",CLASSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_Naiss", renderer, "text",DDJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_Naiss", renderer, "text",DDM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_Naiss", renderer, "text",DDA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_E", renderer, "text",DEJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_E", renderer, "text",DEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_E", renderer, "text",DEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_S", renderer, "text",DSJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_S", renderer, "text",DSM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_S", renderer, "text",DSA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Bloc", renderer, "text",BLOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num_chambre", renderer, "text",NUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Etage", renderer, "text",ETAGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Paiement", renderer, "text",PAIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
     store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);

    f=fopen("etudiant.txt","r");

if(f==NULL)
{
return;
}
else 
{
f=fopen("etudiant.txt","a+");
while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF){  
	if(e.ref_ch.etage==2)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store, &iter, SEXE, e.sexe, CIN, e.cin, NOM, e.nom, PRENOM, e.prenom, CLASSE, e.classe, DDJ, e.date_de_naissance.j, DDM, e.date_de_naissance.m, DDA, e.date_de_naissance.a, DEJ, e.date_entree.j, DEM, e.date_entree.m, DEA, e.date_entree.a, DSJ, e.date_sortie.j, DSM, e.date_sortie.m, DSA, e.date_sortie.a, BLOC, e.ref_ch.bloc, NUM, e.ref_ch.num, ETAGE, e.ref_ch.etage, PAIE, e.paiement,-1);
	n++;
	}
}
   fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
return n;
}

//////////////////////////////////////////

int afficher3eme(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

	int k=0;

    char Sexe [30];
    char Cin [9];
    char Nom [30];
    char Prenom[30];
    char Classe[30];
    int j_Naiss;
    int m_Naiss;
    int a_Naiss;
    int j_E;
    int m_E;
    int a_E;
    int j_S;
    int m_S;
    int a_S;
    char Bloc[30];
    int Etage;
    int Num_chambre ;
    char Paiement[30];
   
    etudiant e;

	
    FILE *f;

   store=gtk_tree_view_get_model(liste);
   if (store==NULL)
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Sexe", renderer, "text",SEXE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Cin", renderer, "text",CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new(); 
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Classe", renderer, "text",CLASSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_Naiss", renderer, "text",DDJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_Naiss", renderer, "text",DDM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_Naiss", renderer, "text",DDA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_E", renderer, "text",DEJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_E", renderer, "text",DEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_E", renderer, "text",DEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_S", renderer, "text",DSJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_S", renderer, "text",DSM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_S", renderer, "text",DSA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Bloc", renderer, "text",BLOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num_chambre", renderer, "text",NUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Etage", renderer, "text",ETAGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Paiement", renderer, "text",PAIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}

     store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);

    f=fopen("etudiant.txt","r");

if(f==NULL)
{
return;
}
else 
{
f=fopen("etudiant.txt","a+");
while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF){  
	if(e.ref_ch.etage==3)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store, &iter, SEXE, e.sexe, CIN, e.cin, NOM, e.nom, PRENOM, e.prenom, CLASSE, e.classe, DDJ, e.date_de_naissance.j, DDM, e.date_de_naissance.m, DDA, e.date_de_naissance.a, DEJ, e.date_entree.j, DEM, e.date_entree.m, DEA, e.date_entree.a, DSJ, e.date_sortie.j, DSM, e.date_sortie.m, DSA, e.date_sortie.a, BLOC, e.ref_ch.bloc, NUM, e.ref_ch.num, ETAGE, e.ref_ch.etage, PAIE, e.paiement,-1);
	k++;
	}
}
   fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
return k;
}

////////////////////////////////////////
int afficher4eme(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

	int x=0;

    char Sexe [30];
    char Cin [9];
    char Nom [30];
    char Prenom[30];
    char Classe[30];
    int j_Naiss;
    int m_Naiss;
    int a_Naiss;
    int j_E;
    int m_E;
    int a_E;
    int j_S;
    int m_S;
    int a_S;
    char Bloc[30];
    int Etage;
    int Num_chambre ;
    char Paiement[30];
   
    etudiant e;


    FILE *f;
    
   store=gtk_tree_view_get_model(liste);
   if (store==NULL)
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Sexe", renderer, "text",SEXE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Cin", renderer, "text",CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new(); 
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Classe", renderer, "text",CLASSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_Naiss", renderer, "text",DDJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_Naiss", renderer, "text",DDM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_Naiss", renderer, "text",DDA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_E", renderer, "text",DEJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_E", renderer, "text",DEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_E", renderer, "text",DEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" j_S", renderer, "text",DSJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" m_S", renderer, "text",DSM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" a_S", renderer, "text",DSA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Bloc", renderer, "text",BLOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num_chambre", renderer, "text",NUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Etage", renderer, "text",ETAGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Paiement", renderer, "text",PAIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
     store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);

    f=fopen("etudiant.txt","r");

if(f==NULL)
{
return;
}
else 
{
f=fopen("etudiant.txt","a+");
while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d %d %d %d %s %d %d %s\n",e.sexe,e.cin,e.nom,e.prenom,e.classe,&e.date_de_naissance.j,&e.date_de_naissance.m,&e.date_de_naissance.a,&e.date_entree.j,&e.date_entree.m,&e.date_entree.a,&e.date_sortie.j,&e.date_sortie.m,&e.date_sortie.a,e.ref_ch.bloc,&e.ref_ch.num,&e.ref_ch.etage,e.paiement)!=EOF){  
	if(e.ref_ch.etage==4)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store, &iter, SEXE, e.sexe, CIN, e.cin, NOM, e.nom, PRENOM, e.prenom, CLASSE, e.classe, DDJ, e.date_de_naissance.j, DDM, e.date_de_naissance.m, DDA, e.date_de_naissance.a, DEJ, e.date_entree.j, DEM, e.date_entree.m, DEA, e.date_entree.a, DSJ, e.date_sortie.j, DSM, e.date_sortie.m, DSA, e.date_sortie.a, BLOC, e.ref_ch.bloc, NUM, e.ref_ch.num, ETAGE, e.ref_ch.etage, PAIE, e.paiement,-1);
	x++;
	}
}
   fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
return x;
}


