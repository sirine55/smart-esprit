#include <gtk/gtk.h>


void
on_chajouter_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_channulera_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_chpaye_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chcheckbutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chnonpaye_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chretoura_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chtreeview7_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chchercheret_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chajouteret_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chmodifieret_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chsupprimeret_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chlisteetud_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chretourmenu_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_chactualiserm_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_channulers_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chvaliders_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chafficherm_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chpayem_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chnonpayem_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chcheckbutton3_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chcheckbutton4_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chvaliderm_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_channulerm_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chbutton2_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chtreeview2_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chchercherch_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chactualiserch_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chretourch_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chtreeview14_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chtreeview12_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chtreeview11_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chtreeview13_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chafficher1_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chafficher2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chafficher3_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chafficher4_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chretourlist_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
