#include <gtk/gtk.h>

enum
{
	PREF,
	PNOM,
	PTYPE,
	PQUANTITE,
	PPRIX,
	PDATE,
	PDATEM,
	PDATEA,
	PDELAISJ,
	PDELAISM,
	PDELAISA,
	COLUMN
};

enum
{
	ENOM,
	ENUMERO,
	EFAX,
	ELOC,
	ETYPE,
	COLUMNS
};

typedef struct
{
    int j;
    int m;
    int a;
}date;

typedef struct
{
    char ref[20];
    char type[20];
    char nom[20];;
    int quantite;
    char prix[20];
    date datemod;
    date delais;
}produit;

typedef struct
{
	char nom[20];
	char fax[20];
	char num[20];
	char loc[50];
	char type[20];
}fournisseur;
	

void ajout_produit(produit p);
void modifier_produit(produit p);
void chercher_produit();
void vider (GtkWidget *liste);
int exist(char ref[10],	produit p);
void supprimer_produit(produit p, char l[20]);
void afficher(GtkWidget *liste);
void afficherchercher(GtkWidget *liste,char l[20]);
void afficherrep(GtkWidget *liste);
int existfournisseur(char test[20],	fournisseur e);
void ajout_fournisseur(fournisseur e);
void supprimer_fournisseur(fournisseur e, char num[20]);
void afficherfournisseurlegume(GtkWidget *liste);
void afficherfournisseurfruit(GtkWidget *liste);
void afficherfournisseurautre(GtkWidget *liste);
void rechercheraffichermodifier (produit z, char ref[20])	;


