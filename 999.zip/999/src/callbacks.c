#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "produit.h"


int x=0;
int y=0;
int f=0;

void
on_azmodifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azmodifier();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azproduit");
	gtk_widget_destroy(window2);
}


void
on_azsupprimer_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azsupprimer();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azproduit");
	gtk_widget_destroy(window2);
}


void
on_azajouter_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azajouter();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azproduit");
	gtk_widget_destroy(window2);
}


void
on_azchercher_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azchercher();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azproduit");
	gtk_widget_destroy(window2);
}


void
on_azreptureb_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azrepture();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azproduit");
	gtk_widget_destroy(window2);
}





void
on_azfournisseur_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azfournisseur();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azproduit");
	gtk_widget_destroy(window2);
}


void
on_azretour_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_azfruit_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			x=2;
		}	
}


void
on_azlegume_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			x=1;
		}	
}


void
on_azautre_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			x=3;
		}	
}


void
on_azvalidera_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *reference;
	GtkWidget *nom;
	GtkWidget *type;
	GtkWidget *legume;
	GtkWidget *fruit;
	GtkWidget *autre;
	GtkWidget *combo;
	GtkWidget *quantite;
	GtkWidget *j;
	GtkWidget *m;
	GtkWidget *a;
	GtkWidget *jd;
	GtkWidget *md;
	GtkWidget *ad;
	GtkWidget *prix;
	GtkWidget *msg;
	produit p;
	char test[20];
	reference=lookup_widget(objet,"azreference");
	nom=lookup_widget(objet,"aznom");
	quantite=lookup_widget(objet,"azquantite");
	j=lookup_widget(objet,"azj");
	m=lookup_widget(objet,"azm");
	a=lookup_widget(objet,"aza");
	jd=lookup_widget(objet,"azjd");
	md=lookup_widget(objet,"azmd");
	ad=lookup_widget(objet,"azad");
	prix=lookup_widget(objet,"azprixa");
	legume=lookup_widget(objet,"azlegume");
	fruit=lookup_widget(objet,"azfruit");
	autre=lookup_widget(objet,"azautre");
	combo=lookup_widget(objet,"azlistm");
	msg=lookup_widget(objet,"azmsg");

	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference))); 
	strcpy(test,p.ref);
	strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(p.prix,gtk_entry_get_text(GTK_ENTRY(prix)));
	p.quantite=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (quantite));
	p.datemod.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (j));
	p.datemod.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (m));
	p.datemod.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (a));
	p.delais.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jd));
	p.delais.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (md));
	p.delais.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (ad));

	if (x==1)
		{
			strcpy(p.type,"legume");
		}
	else if (x==2)
		{
			strcpy(p.type,"fruit");
		}
	else if (x==3)
		{
			strcpy(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo)));
		}
	strcpy(test,p.ref);
	if(exist(test,p)==1)
	{
		gtk_label_set_text(GTK_LABEL(msg),"exist");
		gtk_widget_show(msg);
	}
	else 
	{
		ajout_produit(p);
		gtk_label_set_text(GTK_LABEL(msg),"Produit ajouter avec succés");
		gtk_widget_show(msg);
	}
}


void
on_azretoura_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azproduit();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azajouter");
	gtk_widget_destroy(window2);
}


void
on_azvaliders_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *refs;
	GtkWidget *msg;
	char r[20];
	produit p;
	refs=lookup_widget(objet,"azrefs");
	msg=lookup_widget(objet,"azlabel34");
	strcpy(r,gtk_entry_get_text(GTK_ENTRY(refs))); 
	if(exist(r,p)==1)
		{
			supprimer_produit(p,r);
			gtk_label_set_text(GTK_LABEL(msg),"Le produit est supprimé avec succés");
			gtk_widget_show(msg);
		}
	else 
		{
			gtk_label_set_text(GTK_LABEL(msg),"Acun produit avec cette reference");
			gtk_widget_show(msg);
		}	
}


void
on_azannulers_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azproduit();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azsupprimer");
	gtk_widget_destroy(window2);
}


void
on_aztreeview1_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	
}







void
on_azvaliderm_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *reference;
	GtkWidget *nom;
	GtkWidget *type;
	GtkWidget *prix;
	GtkWidget *quantite;
	GtkWidget *j;
	GtkWidget *m;
	GtkWidget *a;
	GtkWidget *jd;
	GtkWidget *md;
	GtkWidget *ad;
	GtkWidget *combo;
	GtkWidget *msg;
	GtkWidget *msg2;

	produit p;
	char l[20];
	
	reference=lookup_widget(objet,"azrefm");
	nom=lookup_widget(objet,"aznomm");
	quantite=lookup_widget(objet,"azquantitem");
	j=lookup_widget(objet,"azjm");
	m=lookup_widget(objet,"azmm");
	a=lookup_widget(objet,"azam");
	jd=lookup_widget(objet,"azjdm");
	md=lookup_widget(objet,"azmdm");
	ad=lookup_widget(objet,"azadm");
	type=lookup_widget(objet,"aztypem");
	combo=lookup_widget(objet,"azlistmmm");
	prix=lookup_widget(objet,"azprixm");
	msg2=lookup_widget(objet,"azlabel41");
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference))); 
	strcpy(l,p.ref);
	supprimer_produit(p,l);
	strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(p.prix,gtk_entry_get_text(GTK_ENTRY(prix)));
	p.quantite=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (quantite));
	p.datemod.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (j));
	p.datemod.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (m));
	p.datemod.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (a));
	p.delais.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jd));
	p.delais.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (md));
	p.delais.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (ad));
	msg=lookup_widget(objet,"azlabel71");
	
	
	if (y==1)
		{
			strcpy(p.type,"legume");
		}
	else if (y==2)
		{
			strcpy(p.type,"fruit");
		}
	else if (y==3)
		{
			strcpy(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo)));
		}
	else if (y==0)
		{
		strcpy(p.type,gtk_entry_get_text(GTK_ENTRY(type)));
		}

	ajout_produit(p);
	gtk_label_set_text(GTK_LABEL(msg),"Le produit est mettre à jour");
	gtk_widget_show(msg);
	gtk_widget_hide(msg2);
}


void
on_azretourm_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azproduit();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azmodifier");
	gtk_widget_destroy(window2);
}


void
on_azcherchermodif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ref;
	GtkWidget *msg;
	GtkWidget *nom;
	GtkWidget *prix;
	GtkWidget *quantite;
	GtkWidget *datemodj;
	GtkWidget *datemodm;
	GtkWidget *datemoda;
	GtkWidget *delaisj;
	GtkWidget *delaism;
	GtkWidget *delaisa;
	GtkWidget *legume;
	GtkWidget *fruit;
	GtkWidget *autre;
	GtkWidget *list;
	char r[20];
	produit p;
	FILE *f;

	ref=lookup_widget(objet,"azrefm");
	nom=lookup_widget(objet,"aznomm");
	prix=lookup_widget(objet,"azprixm");
	msg=lookup_widget(objet,"azlabel41");
	datemodj=lookup_widget(objet,"azjm");
	datemodm=lookup_widget(objet,"azmm");
	datemoda=lookup_widget(objet,"azam");
	delaisj=lookup_widget(objet,"azjdm");
	delaism=lookup_widget(objet,"azmdm");
	delaisa=lookup_widget(objet,"azadm");
	legume=lookup_widget(objet,"azlegumem");
	fruit=lookup_widget(objet,"azfruitm");
	autre=lookup_widget(objet,"azautrem");
	list=lookup_widget(objet,"azlistmmm");
	quantite=lookup_widget(objet,"azquantitem");

	strcpy(r,gtk_entry_get_text(GTK_ENTRY(ref)));

	if(exist(r,p)==1)
	{	
		rechercheraffichermodifier (p,r);
		f=fopen("tmpo.txt","r");
		while(fscanf(f,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,&p.quantite,p.prix,&p.datemod.j,&p.datemod.m,&p.datemod.a,&p.delais.j,&p.delais.m,&p.delais.a)!=EOF)
		{
			gtk_entry_set_text(GTK_ENTRY(nom),p.nom);
			gtk_entry_set_text(GTK_ENTRY(prix),p.prix);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(datemodj),p.datemod.j);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(datemodm),p.datemod.m);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(datemoda),p.datemod.a);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(delaisj),p.delais.j);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(delaism),p.delais.m);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(delaisa),p.delais.a);
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(quantite),p.quantite);
			if(strcmp(p.type,"legume")==0)
				{
					gtk_toggle_button_set_active(legume,1);
				}
			else if (strcmp(p.type,"fruit")==0)
				{
					gtk_toggle_button_set_active(fruit,1);
				}
			else
				{
					gtk_toggle_button_set_active(autre,1);
					//strcat(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX("listmmm")));
					gtk_toggle_button_set_active(legume,0);
					gtk_toggle_button_set_active(fruit,0);
				}

			gtk_label_set_text(GTK_LABEL(msg),"Les paramétres du produit sont affichés avec succés");
			gtk_widget_show(msg);
			remove("tmpo.txt");
		}
	}
	else
	{
		gtk_label_set_text(GTK_LABEL(msg),"Acun produit avec cette reference");
		gtk_widget_show(msg);
	}
}


void
on_azfruitm_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			y=2;
		}
}


void
on_azautrem_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			y=3;
		}
}


void
on_azlegumem_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			y=1;
		}
}


void
on_aztreeview2_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_azactualiserchercher_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *cherch, *w1;
	GtkWidget *treeview2;
	GtkWidget *chercher;
	char l[20];
	chercher=lookup_widget(objet,"azrefcher");
	strcpy(l,gtk_entry_get_text(GTK_ENTRY(chercher)));
	w1=lookup_widget(objet,"azchercher");
	cherch=create_azchercher();
	gtk_widget_show(cherch);
	gtk_widget_hide(w1);	
	treeview2=lookup_widget(cherch,"aztreeview2");
	vider(treeview2);
	afficherchercher(treeview2,l);
}


void
on_azretourcher_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azproduit();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azchercher");
	gtk_widget_destroy(window2);
}


void
on_azchercherchercher_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *chercher;
	GtkWidget *msg;
	char l[20];
	produit p;
	GtkWidget *treeview2;
	msg=lookup_widget(objet,"azlabel40");
	chercher=lookup_widget(objet,"azrefcher");
	treeview2=lookup_widget(objet,"aztreeview2");
	strcpy(l,gtk_entry_get_text(GTK_ENTRY(chercher)));
	if(exist(l,p)==1)
	{ 
		afficherchercher(treeview2,&l);
		gtk_label_set_text(GTK_LABEL(msg),"Le produit est affiché avec succés");
		gtk_widget_show(msg);
	}
	else
	{
		gtk_label_set_text(GTK_LABEL(msg),"Acun produit avec cette reference");
		gtk_widget_show(msg);
	
	}
}


void
on_aztreeview3_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_azactualiserhstock_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *rep, *w1;
	GtkWidget *treeview3;
	w1=lookup_widget(objet,"azrepture");
	rep=create_azrepture();
	gtk_widget_show(rep);
	gtk_widget_hide(w1);	
	treeview3=lookup_widget(rep,"aztreeview3");
	vider(treeview3);
	afficherrep(treeview3);

}


void
on_azretourhstock_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azproduit();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azrepture");
	gtk_widget_destroy(window2);
}


void
on_azajoutfournisseur_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azajouterfournisseur();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azfournisseur");
	gtk_widget_destroy(window2);
}


void
on_azafficherfourleg_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azfournisseurlegume();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azfournisseur");
	gtk_widget_destroy(window2);
}


void
on_azafficheurfourfruit_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2, *treeview5;
	window1=create_azfournisseurfruit();
	gtk_widget_show (window1);
	window2=lookup_widget(objet,"azfournisseur");
	gtk_widget_destroy(window2);	
}


void
on_azafficherfourautres_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azfournisseurautre();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azfournisseur");
	gtk_widget_destroy(window2);
}


void
on_azsupprimerfournisseur_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azsuppfournisseur();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azfournisseur");
	gtk_widget_destroy(window2);
}


void
on_azretourfournisseur_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azproduit();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azfournisseur");
	gtk_widget_destroy(window2);
}


void
on_azautresoc_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			f=3;
		}
}


void
on_azfruitsoc_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			f=2;
		}
}


void
on_azlegumesoc_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		{
			f=1;
		}
}


void
on_azvaliderfour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *nom;
	GtkWidget *fax;
	GtkWidget *num;
	GtkWidget *loc;
	GtkWidget *type;
	GtkWidget *legume;
	GtkWidget *fruit;
	GtkWidget *autre;
	GtkWidget *combo;
	GtkWidget *msg;
	fournisseur e;
	char test[20];

	nom=lookup_widget(objet,"aznomsoc");
	fax=lookup_widget(objet,"azfaxsoc");
	num=lookup_widget(objet,"aznumsoc");
	loc=lookup_widget(objet,"azadresssoc");
	legume=lookup_widget(objet,"azlegumesoc");
	fruit=lookup_widget(objet,"azfruitsoc");
	autre=lookup_widget(objet,"azautresoc");
	combo=lookup_widget(objet,"azcombobox1");
	msg=lookup_widget(objet,"azlabel54");

	strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom))); 
	strcpy(e.fax,gtk_entry_get_text(GTK_ENTRY(fax))); 
	strcpy(e.num,gtk_entry_get_text(GTK_ENTRY(num))); 
	strcpy(e.loc,gtk_entry_get_text(GTK_ENTRY(loc))); 

	if (f==1)
		{
			strcpy(e.type,"legume");
		}
	else if (f==2)
		{
			strcpy(e.type,"fruit");
		}
	else if (f==3)
		{
			strcpy(e.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo)));
		}
	strcpy(test,e.num);
	if(existfournisseur(test,e)==1)
	{
		gtk_label_set_text(GTK_LABEL(msg),"exist");
		gtk_widget_show(msg);
	}
	else 
	{
		ajout_fournisseur(e);
		gtk_label_set_text(GTK_LABEL(msg),"Fournisseur ajouter avec succés");
		gtk_widget_show(msg);
	}
}


void
on_azretourajoutfournisseur_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azfournisseur();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azajouterfournisseur");
	gtk_widget_destroy(window2);
}


void
on_aztreeview4_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* nom[20];
	gchar* num[20];
	char n[20];
	fournisseur e;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&num,-1);
	strcpy(n,*num);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce fournisseur?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_fournisseur(e,n);
	//vider(treeview);
	afficherfournisseurlegume(treeview);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}


void
on_azactualiserfournisseurlegume_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview4;
	treeview4=lookup_widget(objet,"aztreeview4");
	afficherfournisseurlegume(treeview4);
}


void
on_azretourfournisseurlegume_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azfournisseur();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azfournisseurlegume");
	gtk_widget_destroy(window2);
}


void
on_aztreeview5_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* nom[20];
	gchar* num[20];
	char n[20];
	fournisseur e;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&num,-1);
	strcpy(n,*num);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce fournisseur?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_fournisseur(e,n);
	//vider(treeview);
	afficherfournisseurfruit(treeview);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}


void
on_azretourfournisseurfruit_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azfournisseur();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azfournisseurfruit");
	gtk_widget_destroy(window2);
}


void
on_azactualiserfournisseurfruit_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview5;
	treeview5=lookup_widget(objet,"aztreeview5");
	afficherfournisseurfruit(treeview5);
}


void
on_aztreeview6_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* nom[20];
	gchar* num[20];
	char n[20];
	fournisseur e;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&num,-1);
	strcpy(n,*num);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce fournisseur?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_fournisseur(e,n);
	//vider(treeview);
	afficherfournisseurautre(treeview);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}


void
on_azretourfournisseurautre_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azfournisseur();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azfournisseurautre");
	gtk_widget_destroy(window2);
}


void
on_azactualiserfournisseurautre_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview6;
	treeview6=lookup_widget(objet,"aztreeview6");
	afficherfournisseurautre(treeview6);
}


void
on_azretoursfournisseur_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2;
	window1=create_azfournisseur();
	gtk_widget_show (window1);
	window2=lookup_widget(button,"azsuppfournisseur");
	gtk_widget_destroy(window2);
}


void
on_azvalidersfournisseur_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *supp;
	GtkWidget *msg;
	char r[20];
	fournisseur e;
	supp=lookup_widget(objet,"azsuppnumfour");
	msg=lookup_widget(objet,"azlabel67");
	strcpy(r,gtk_entry_get_text(GTK_ENTRY(supp))); 
	if(existfournisseur(r,e)==1)
		{
			supprimer_fournisseur(e,r);
			gtk_label_set_text(GTK_LABEL(msg),"Le fournisseur est supprimé avec succés");
			gtk_widget_show(msg);
		}
	else 
		{
			gtk_label_set_text(GTK_LABEL(msg),"Acun fournisseur avec ce numéro");
			gtk_widget_show(msg);
		}
}





void
on_azaffprod_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *affich, *w1;
	GtkWidget *treeview1;
	w1=lookup_widget(objet,"azproduit");
	affich=create_azproduit();
	gtk_widget_show(affich);
	gtk_widget_hide(w1);	
	treeview1=lookup_widget(affich,"aztreeview122");
	vider(treeview1);
	afficher(treeview1);
}


void
on_azchercherprod_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_aztreeview122_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* ref[20];
	char n[20];
	produit p;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,-1);
	strcpy(n,*ref);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce produit?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_produit(p,n);
	//vider(treeview);
	afficher(treeview);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}

