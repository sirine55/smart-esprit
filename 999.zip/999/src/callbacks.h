#include <gtk/gtk.h>


void
on_azmodifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_azsupprimer_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_azajouter_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_azchercher_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_azreptureb_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_azafficher_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_azfournisseur_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_azretour_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_azfruit_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_azlegume_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_azautre_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_azvalidera_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azretoura_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_azvaliders_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azannulers_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_aztreeview1_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_azretouraf_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_azactuaf_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azvaliderm_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azretourm_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_azcherchermodif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azfruitm_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_azautrem_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_azlegumem_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aztreeview2_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_azactualiserchercher_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azretourcher_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_azchercherchercher_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aztreeview3_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_azactualiserhstock_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azretourhstock_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_azajoutfournisseur_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_azafficherfourleg_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_azafficheurfourfruit_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azafficherfourautres_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_azsupprimerfournisseur_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_azretourfournisseur_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_azautresoc_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_azfruitsoc_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_azlegumesoc_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_azvaliderfour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azretourajoutfournisseur_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_aztreeview4_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_azactualiserfournisseurlegume_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azretourfournisseurlegume_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_aztreeview5_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_azretourfournisseurfruit_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_azactualiserfournisseurfruit_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aztreeview6_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_azretourfournisseurautre_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_azactualiserfournisseurautre_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azretoursfournisseur_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_azvalidersfournisseur_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_azaffprod_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_azchercherprod_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_aztreeview122_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
