#include "produit.h"
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>	
#include <string.h>

void ajout_produit(produit p)
{
	FILE *f;
	f=fopen("produit.txt","a+");
	fprintf(f,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,p.quantite,p.prix,p.datemod.j,p.datemod.m,p.datemod.a,p.delais.j,p.delais.m,p.delais.a);
	fclose(f);
}

//////////////////////////////////////

int exist(char ref[20] 	, produit p)
{
	FILE *f;
	f=fopen("produit.txt","r");
 	while(fscanf(f,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,&p.quantite,p.prix,&p.datemod.j,&p.datemod.m,&p.datemod.a,&p.delais.j,&p.delais.m,&p.delais.a)!=EOF)
		{
		if(strcmp(ref,p.ref)==0)
			return 1; 
		}
	fclose(f);
	return 0;
}

void afficher(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	produit p ;
	char ref[20];
    	char type[20];
    	char nom[20];;
  	int quantite;
	char prix[20];
	int j;
	int m;
	int a;
	int jd;
	int md;
	int ad;
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);
	

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Réference", renderer, "text", PREF, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", PNOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text", PTYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Quantité", renderer, "text", PQUANTITE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("PRIX", renderer, "text", PPRIX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour modification", renderer, "text", PDATE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois modification", renderer, "text", PDATEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année modification", renderer, "text", PDATEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour delais", renderer, "text", PDELAISJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois delais", renderer, "text", PDELAISM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année delais", renderer, "text", PDELAISA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
	f=fopen("produit.txt","r");
	if(f==NULL)
	{
		return;
	}
	else 
	{
		f=fopen("produit.txt","a+");
		while(fscanf(f,"%s %s %s %d %s %d %d %d %d %d %d\n",ref,nom,type,&quantite,prix,&j,&m,&a,&jd,&md,&ad)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, PREF, ref, PNOM, nom, PTYPE, type, PQUANTITE, quantite, PPRIX, prix, PDATE, j, PDATEM, m, PDATEA, a, PDELAISJ, jd, PDELAISM, md, PDELAISA, ad,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
}

void vider(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	produit p ;
	char ref[20];
    	char type[20];
    	char nom[20];
  	int quantite;
	char prix[20];
	int j;
	int m;
	int a;
	int jd;
	int md;
	int ad;
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);
	

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Réference", renderer, "text", PREF, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", PNOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text", PTYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Quantité", renderer, "text", PQUANTITE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("PRIX", renderer, "text", PPRIX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour modification", renderer, "text", PDATE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois modification", renderer, "text", PDATEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année modification", renderer, "text", PDATEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour delais", renderer, "text", PDELAISJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois delais", renderer, "text", PDELAISM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année delais", renderer, "text", PDELAISA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
	gtk_list_store_append (store, &iter);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		/*g_object_unref (store);*/
}

void supprimer_produit(produit p, char l[20])
{
	FILE *f;
   	FILE *tmp;
    	f=fopen("produit.txt","a+");
    	tmp=fopen("tmp.txt","w");
	
       	while(fscanf(f,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,&p.quantite,p.prix,&p.datemod.j,&p.datemod.m,&p.datemod.a,&p.delais.j,&p.delais.m,&p.delais.a)!=EOF)
       		{
       		 if (strcmp(l,p.ref)!=0)
          		fprintf(tmp,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,p.quantite,p.prix,p.datemod.j,p.datemod.m,p.datemod.a,p.delais.j,p.delais.m,p.delais.a);
      		}
        fclose(f);
        fclose(tmp);
        remove("produit.txt");
        rename("tmp.txt","produit.txt");
}


void afficherchercher(GtkWidget *liste,char l[])
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	produit p ;
	char ref[20];
    	char type[20];
    	char nom[20];;
  	int quantite;
	char prix[20];
	int j;
	int m;
	int a;
	int jd;
	int md;
	int ad;
	store=NULL;

	FILE *f;
	
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Réference", renderer, "text", PREF, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", PNOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text", PTYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Quantité", renderer, "text", PQUANTITE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("PRIX", renderer, "text", PPRIX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour modification", renderer, "text", PDATE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois modification", renderer, "text", PDATEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année modification", renderer, "text", PDATEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour delais", renderer, "text", PDELAISJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois delais", renderer, "text", PDELAISM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année delais", renderer, "text", PDELAISA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
	f=fopen("produit.txt","r");
	if(f==NULL)
	{
		return;
	}
	else 
	{
		f=fopen("produit.txt","a+");
		while(fscanf(f,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,&p.quantite,p.prix,&p.datemod.j,&p.datemod.m,&p.datemod.a,&p.delais.j,&p.delais.m,&p.delais.a)!=EOF)
		{
			if (strcmp(l,p.ref)==0){
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, PREF, p.ref, PNOM, p.nom, PTYPE, p.type, PQUANTITE, p.quantite, PPRIX, p.prix, PDATE, p.datemod.j, PDATEM, p.datemod.m, PDATEA, p.delais.a, PDELAISJ, p.delais.j, PDELAISM, p.delais.m, PDELAISA, p.delais.a,-1);}
			
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}


}

void afficherrep(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	produit p ;
	char ref[20];
    	char type[20];
    	char nom[20];;
  	int quantite;
	char prix[20];
	int j;
	int m;
	int a;
	int jd;
	int md;
	int ad;
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);
	

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Réference", renderer, "text", PREF, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", PNOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text", PTYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Quantité", renderer, "text", PQUANTITE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("PRIX", renderer, "text", PPRIX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour modification", renderer, "text", PDATE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois modification", renderer, "text", PDATEM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année modification", renderer, "text", PDATEA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Jour delais", renderer, "text", PDELAISJ, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Mois delais", renderer, "text", PDELAISM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année delais", renderer, "text", PDELAISA, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
	f=fopen("produit.txt","r");
	if(f==NULL)
	{
		return;
	}
	else 
	{
		while(fscanf(f,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,&p.quantite,p.prix,&p.datemod.j,&p.datemod.m,&p.datemod.a,&p.delais.j,&p.delais.m,&p.delais.a)!=EOF)
		{
			if(p.quantite==0)
			{
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, PREF, p.ref, PNOM, p.nom, PTYPE, p.type, PQUANTITE, p.quantite, PPRIX, p.prix, PDATE, p.datemod.j, PDATEM, p.datemod.m, PDATEA, p.datemod.a, PDELAISJ, p.delais.j, PDELAISM, p.delais.m, PDELAISA, p.delais.a,-1);
			}		
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
				
}

int existfournisseur(char test[] , fournisseur e)
{
	FILE *f;
	f=fopen("four2.txt","r");
 	while(fscanf(f,"%s %s %s %s %s\n",e.nom,e.num,e.fax,e.loc,e.type)!=EOF)
		{
		if(strcmp(test,e.num)==0)
			return 1; 
		}
	fclose(f);
	return 0;
}

void ajout_fournisseur(fournisseur e)
{
	FILE *f;
	f=fopen("four2.txt","a+");
	fprintf(f,"%s %s %s %s %s\n",e.nom,e.num,e.fax,e.loc,e.type);
	fclose(f);
}

void supprimer_fournisseur(fournisseur e, char num[])
{
	FILE *f;
   	FILE *tmp;
    	f=fopen("four2.txt","r");
    	tmp=fopen("tmp2.txt","w");
	
       	while(fscanf(f,"%s %s %s %s %s\n",e.nom,e.num,e.fax,e.loc,e.type)!=EOF)
       		{
		if(strcmp(num,e.num)!=0)
          		fprintf(tmp,"%s %s %s %s %s\n",e.nom,e.num,e.fax,e.loc,e.type);
      		}
        fclose(f);
        fclose(tmp);
        remove("four2.txt");
        rename("tmp2.txt","four2.txt");
}

void afficherfournisseurlegume(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	fournisseur e;
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", ENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Numéro", renderer, "text", ENUMERO, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("FAX", renderer, "text", EFAX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Localisation", renderer, "text", ELOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type de produit", renderer, "text", ETYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("four2.txt","r");

	if(f==NULL)
	{
		return;
	}
	else 
	{
		while(fscanf(f,"%s %s %s %s %s\n",e.nom,e.num,e.fax,e.loc,e.type)!=EOF)
		{
			if(strcmp(e.type,"legume")==0)
			{
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, ENOM, e.nom, ENUMERO, e.num, EFAX, e.fax, ELOC, e.loc, ETYPE, e.type,-1);
			}		
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
}


void afficherfournisseurfruit(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	fournisseur e ;
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", ENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Numéro", renderer, "text", ENUMERO, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("FAX", renderer, "text", EFAX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Localisation", renderer, "text", ELOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type de produit", renderer, "text", ETYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("four2.txt","r");

	if(f==NULL)
	{
		return;
	}
	else 
	{
		while(fscanf(f,"%s %s %s %s %s\n",e.nom,e.num,e.fax,e.loc,e.type)!=EOF)
		{
			if(strcmp(e.type,"fruit")==0)
			{
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, ENOM, e.nom, ENUMERO, e.num, EFAX, e.fax, ELOC, e.loc, ETYPE, e.type,-1);
			}		
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
}


void afficherfournisseurautre(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	fournisseur e ;
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", ENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Numéro", renderer, "text", ENUMERO, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("FAX", renderer, "text", EFAX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Localisation", renderer, "text", ELOC, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type de produit", renderer, "text", ETYPE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("four2.txt","r");

	if(f==NULL)
	{
		return;
	}
	else 
	{
		while(fscanf(f,"%s %s %s %s %s\n",e.nom,e.num,e.fax,e.loc,e.type)!=EOF)
		{
			if((strcmp(e.type,"Plats")==0)||(strcmp(e.type,"Coutaux")==0)||(strcmp(e.type,"Fourchettes")==0)||(strcmp(e.type,"Cuillères")==0))
			{
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, ENOM, e.nom, ENUMERO, e.num, EFAX, e.fax, ELOC, e.loc, ETYPE, e.type,-1);
			}		
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
}

void rechercheraffichermodifier (produit p, char ref[])	
{
	FILE *f, *tmpo;
	tmpo=fopen("tmpo.txt","w");
	f=fopen("produit.txt","r");
	while(fscanf(f,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,&p.quantite,p.prix,&p.datemod.j,&p.datemod.m,&p.datemod.a,&p.delais.j,&p.delais.m,&p.delais.a)!=EOF)
		{
		if(strcmp(ref,p.ref)==0)
			{
				fprintf(tmpo,"%s %s %s %d %s %d %d %d %d %d %d\n",p.ref,p.nom,p.type,p.quantite,p.prix,p.datemod.j,p.datemod.m,p.datemod.a,p.delais.j,p.delais.m,p.delais.a);	
			}
		}
		fclose(f);
		fclose(tmpo);
}











